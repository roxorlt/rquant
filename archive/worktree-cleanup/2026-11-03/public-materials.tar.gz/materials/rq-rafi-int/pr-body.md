Fixes #218
Refs #207 #220 #215

路线 A 的包 F。2026-09-07 第一次真正跑完路线 A 之后，live 平面的 completion signer / router / broker 和两个 recovery oneshot 全部起不来（#218）。这个 PR 修其中属于代码缺陷的三条，并把剩下那条属于启动顺序的写进部署前置。

## 改了什么

**A —— `strategy_live` 的完成签名器把已经冻结的 profile manifest 又验了一遍。**
`runtime_service_main.build_runtime_strategy_completion_attestation_signer` 把 `profile.manifests` 的每一项直接交给 `RuntimeServiceManifest.model_validate`，而那些项已经是校验过的模型实例；`RuntimeContractModel` 开着 `revalidate_instances="always"`，manifest 自己的 `freeze_settings` 又把嵌套 list 变成 tuple、嵌套 dict 变成 `MappingProxyType`，两者都不是 `JsonValue`。生产画像里有 9 份 manifest 带嵌套 settings，于是三个 `strategy_live` 实例全部以 `strategy completion signer profile contains invalid manifests` 失败。改法与 `thaw_prevalidated_manifests`、`runtime_production_profile._revalidate_production_inputs` 同款：先 `model_dump(mode="json")` 再验；**「本来就不是模型」的项仍然照旧重验，指纹绑定一字未改**。

**B —— 两个 recovery oneshot 拿自己的内容哈希去比权威链的 generation id。**
`runtime_recovery_production` 用 `recovery.profile_generation`（recovery 段的内容哈希）比 wrapper 的 `--expected-generation`（`sha256(<generation>/full-manifest.json)`），两个不同文档的哈希按构造永不相等，所以路线 A 一给出真实 `current`，`rquant-runtime-recovery@` 与 `-rehearsal@` 就都以 `recovery unit profile generation is stale` 失败。这与 #187/#207 同类，而 #207 的补救只做在 `runtime_service_main` 里。**没有放宽任何核对**：一条不可能成立的比较换成两条能过也能拒的——recovery 命名空间比 retention owner manifest 里的 `recovery_profile_generation`，权威命名空间走 `resolve_legacy_schema_generation`（manifest 必须在 `<expected-generation>/manifests/` 下，该代的 `legacy-binding.json` 必须指名本 runtime root 与 `current` 解析到的 generation）。两者都不给的调用方被拒绝，**不存在「不绑定就跑」的模式**。

**C —— recovery 的两份文档终于有了生产者。**
`data/recovery/runtime-recovery.json` 与 `runtime-recovery-backup.json` 由已安装画像指定路径，而仓库里从来没有任何脚本、CLI 或文档写过它们。新增 `scripts/provision_runtime_recovery_credentials.py`，从 `<runtime root>/current/deployment-profile.json` 派生 backup config 的全部字段，操作员只需给出 replay 窗口；HMAC 密钥用 `secrets.token_hex(64)` 现场生成，两份文档都以 0600 经暂存改名原子落盘，**密钥从不打印、也没有任何传入密钥的参数**。`--only-missing` 保留已存在的凭证而不轮换；**已存在但权限被放宽（不是 0600）或不是普通文件时报错退出，不静默改写**——静默换掉密钥会让 publication root 里已签的每一份 receipt 与 pointer 全部验不过。

## 审查裁定

独立审查裁定 **`PKGF-REVIEW-APPROVED`**，1 条 must-fix，已在 `42c5d14` 修完：

- **M-1**：`--only-missing` 对一个「已经在签名、但被人 `chmod 0644`」的 `runtime-recovery.json` 会**静默轮换**，正是这个参数存在的目的所要避免的后果。审查员实测复现（0600 复跑 `created: False` 字节不变，改 0644 后同一条命令 `created: True` 密钥被换）。修法是把两态的 `_is_private_regular_file` 换成三态的 `_classify_existing_document`（`absent` / `private` / `insecure`）加 `_should_write`：带 `--only-missing` 时 `insecure` 抛 `ProvisionError`，报错带路径、实测 mode、期望 mode 与该敲的 `chmod`；符号链接同样归 `insecure`。新增 4 条用例，变异 M6（并回两态）能把前三条打红。

审查报告在本机 Mac 的 `/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-f-cc/.superpowers/sdd/2026-09-07-strategy-chain/pkgF-review.md`（不进仓库，`73da865` 把它和包报告一起从版本库移除，磁盘保留）。审查的 should-fix（静态守卫的两个盲区、`--runtime-root` 的生产默认值）与 5 条 note 未在本 PR 处理，等 owner 裁决。

审查另外查实一条**新发现**并立成 #220：`strategy_live` 与 `signal_router` 在文件层互相等对方，是代码层的循环依赖。本 PR **不修**它，也没碰 `deploy/systemd/` 的 `After=`，改用固定启动顺序绕过，写进 `DEPLOY.md`。

## 部署后果

1. **本 tag 改了 `src/rquant/` 三个源文件**（`runtime_service_main.py`、`runtime_recovery_production.py`、`runtime_recovery_service.py`），按既有受控发布链，**下一个窗口必须重新出一代 inputs / 画像 / bundle**（runbook B-6′ → B-7）。`rquant-runtime-exec.pyz` 不受影响——`scripts/build-runtime-exec-pyz.py` 的 `collect_sources` 只打 `src/rquant/runtime_exec_wrapper/**`。这一代同时带着包 E 的 `profile_id` 变化，两者一起换代。
2. **首次在生产机落 recovery 凭证要 owner 单独授权** —— @roxorlt：`data/recovery/runtime-recovery.json` 第一次生成属**新增生产密钥材料**，按受控自动发布模式第 7 条需要你单独明确授权，**不能走无人值守发布器**。前置目录、完整命令与 replay 窗口的判断口径写在 `DEPLOY.md`「路线 A 前置」第 29 条。
3. **live 平面的启动顺序变了**（`DEPLOY.md`「路线 A 前置」第 28 条，#220）：strategy ×3（**这一轮预期失败**，失败信息必须是 `runner source is unavailable: …/signal_bus.sqlite3`，若还是 `invalid manifests` 说明装的不是本代）→ `signal_router` → 显式 `systemctl reset-failed` 加重启 strategy ×3 → paper-broker 与 notifier。中间三条就绪探针的产物都是 `tests/integration/test_route_a_strategy_chain_e2e.py` 断言过的真实文件。**不要指望 `Restart=on-failure` 自愈**：`StartLimitBurst=5` / `RestartSec=10s` 只给约 50 秒。
4. **「`rquant-runtime-strategy@` failed 是设计」这条旧口径作废**，两处出现都已订正：那次 failed 的真实原因是 #218 A 的代码缺陷，不是设计。

## 集成动作（本 PR 的后四个 commit）

- `73da865` 把包 F 的 SDD 工作笔记从版本库移除（磁盘保留）。`.superpowers/` 是未分类的顶层路径，R07 的 `diff_category` 会以 `unclassified repository path needs a reviewed category rule` 拒收，而给它加分类规则不是集成者的裁决。
- `60bc367` 重新生成四个 shard：新增 44 条用例，`full_suite.cases` 13860 → 13904，approved-skips 仍是 55。是 44 不是审查数的 40，因为 M-1 的修复在那次计数之后又加了 4 条。
- `982d467` 上面第 2–4 条的文档落地。
- `b957bd2` R07 重冻结到包 E 的合并 commit `48bd3d8`（tree `4fd0a364`），四处字面量同步；`--staged` 定点迭代到第 3 轮字节复现；`allowed_diff` 23 条，路径集等于 `git diff --raw --no-renames 48bd3d8 HEAD` 的 19 条加本次重冻结自己写的 4 条；`policy_digest` `8131ca5d…9d18c`。

## 本地验收（Mac，`.venv` = 3.11.15，`.venv312` = 3.12.13）

| 跑什么 | 结果 |
|---|---|
| 合并 `origin/main` 后包 F 两个 e2e（3.11） | 16 passed |
| 合并后包 F 四个单测文件（3.11） | 55 passed |
| 合并后包 E 的 credstore 四个文件（3.11） | 60 passed, 1 deselected |
| 合并后 `test_route_a_legacy_binding_e2e.py`（3.11） | 17 passed, 1 deselected |
| R07 门 + 策略重生成 + shard 断言（3.11 / 3.12） | 各 105 passed |
| 包 F 单测 + e2e 全套（3.11 / 3.12） | 各 71 passed |
| `full_suite_shards.py check` 四个 shard | 各 RC 0 |
| `r07_policy_regenerate.py --check` | RC 0 |
| `r07_ci_evidence.py validate --base-sha 48bd3d8… --candidate-sha HEAD` | RC 0，解析出的 baseline commit / tree 与冻结常量逐字节相同 |
| `ruff check` 13 个改动的 `.py` | All checks passed |

已知的改动面外风险：#223（3.12 的 full-suite shard 0 会撞 75 分钟 job 时限），与本 PR 无关。

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01Moh45U775Rd9XxYhx649fg
