"""My own reproduction of risk (c): shadow consumes the spool, live starts from now."""
from __future__ import annotations
import sys, tempfile, pathlib
sys.path.insert(0, "tests/unit")

from datetime import timedelta
import test_runtime_builder_signal as H
from rquant.delivery_contracts import DeliveryChannel, DeliveryTarget, OutboxStatus
from rquant.notification_state import NotificationStateStore
from rquant.runtime_builder_signal import notifier_builder
from rquant.signal_bus import SignalBusStore
from rquant.signal_route_spool import SignalRouteSpool, publish_signal_bus_prefix
from rquant.signal_router_runtime import (
    RoutingDecision,
    SignalRouteCursorStore,
    route_runner_signals,
)
from rquant.strategy_runner import RunnerSignalRecord


class Recorder:
    def __init__(self, name): self.name = name; self.deliveries = []
    def deliver(self, delivery):
        self.deliveries.append(delivery.record.outbox_id)
        return f"{self.name}:{len(self.deliveries)}"


def seed(tmp: pathlib.Path, *, total: int, recipient: str = "admin"):
    """Append `count` more routed signals to the same bus + spool."""
    bus = SignalBusStore(tmp / "signal-bus.sqlite3")
    records = tuple(
        RunnerSignalRecord(sequence=i, signal=H._signal("0123456789abcdef"[i % 16]))
        for i in range(1, total + 1)
    )
    route_runner_signals(
        source_id="n-shape-v1",
        source=H._Source(records),
        bus=bus,
        cursors=SignalRouteCursorStore(tmp / "route-cursor.sqlite3", routing_policy_fingerprint=H.POLICY),
        routed_at=H.NOW,
        target_resolver=lambda _s: RoutingDecision.route(
            routing_policy_fingerprint=H.POLICY,
            targets=(DeliveryTarget(recipient_id=recipient, channel=DeliveryChannel.PUSHDEER),),
        ),
        limit=total,
    )
    publish_signal_bus_prefix(bus=bus, spool=SignalRouteSpool(tmp / "signal-spool"), limit=100)


def statuses(store):
    from collections import Counter
    return dict(Counter(r.status.value for r in store.outbox_records()))


with tempfile.TemporaryDirectory(dir="/Users/roxor/rq-aarev") as td:
    tmp = pathlib.Path(td)
    seed(tmp, total=5)
    store = NotificationStateStore(tmp / "notification-state.sqlite3")

    # --- K = 3 shadow rounds, batch_limit deliberately small (2) to force several rounds
    shadow_provider = Recorder("shadow-side-recorder")
    shadow = notifier_builder(
        provider_loader=lambda: {DeliveryChannel.PUSHDEER: shadow_provider},
        clock=lambda: H.NOW,
    )(H._notifier_manifest(tmp, suppress_delivery=True, batch_limit=2))
    rounds = []
    for k in range(3):
        r = shadow()
        rounds.append((r.input_sequence, r.output_sequence, r.processed_count, r.backlog_count, r.degraded_reasons))
    print("shadow rounds (input_seq, output_seq, processed, backlog, degraded):")
    for r in rounds: print("   ", r)
    print("  recorder that COULD speak saw:", shadow_provider.deliveries)
    print("  outbox statuses after shadow:", statuses(store))
    print("  cursor after shadow:", store.replication_cursor().last_global_sequence)
    receipts = sorted({a.provider_receipt for a in store.attempts()})
    print("  distinct receipts:", receipts)
    print("  all shadow-prefixed:", all(x.startswith("shadow:") for x in receipts), "count:", len(receipts))

    # --- flip to live, nothing new in the spool
    live_provider = Recorder("live")
    live = notifier_builder(
        provider_loader=lambda: {DeliveryChannel.PUSHDEER: live_provider},
        clock=lambda: H.NOW + timedelta(seconds=2),
    )(H._notifier_manifest(tmp, batch_limit=128))
    first_live = live()
    print("\nfirst live round after the flip:", first_live.processed_count, "claimed;",
          "delivered:", live_provider.deliveries, "degraded:", first_live.degraded_reasons)

    # --- two genuinely new signals arrive, then live runs again
    seed(tmp, total=7)
    second_live = live()
    print("after 2 new signals, live round:", second_live.processed_count, "claimed;",
          "delivered:", live_provider.deliveries)
    print("outbox statuses at the end:", statuses(store))
    print("cursor at the end:", store.replication_cursor().last_global_sequence)

    ok = (
        shadow_provider.deliveries == []
        and first_live.processed_count == 0
        and len(live_provider.deliveries) == 2
    )
    print("\nRISK (c) VERDICT:", "HOLDS" if ok else "BROKEN")
