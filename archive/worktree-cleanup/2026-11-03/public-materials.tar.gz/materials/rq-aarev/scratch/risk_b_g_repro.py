"""paused->live storm, risk (b) retry receipt, and the shadow fidelity gap."""
from __future__ import annotations
import sys, tempfile, pathlib
sys.path.insert(0, "tests/unit")
from datetime import timedelta
import test_runtime_builder_signal as H
from rquant.delivery_contracts import DeliveryChannel, DeliveryTarget
from rquant.notification_state import NotificationStateStore
from rquant.runtime_builder_signal import notifier_builder
from rquant.runtime_notification_providers import (
    RecipientNotificationCapabilities, RecipientScopedProviderRegistry,
    RecipientScopedNotificationProvider, NotificationTransportResult,
)
from rquant.signal_bus import SignalBusStore
from rquant.signal_route_spool import SignalRouteSpool, publish_signal_bus_prefix
from rquant.signal_router_runtime import RoutingDecision, SignalRouteCursorStore, route_runner_signals
from rquant.strategy_runner import RunnerSignalRecord
from collections import Counter


class Recorder:
    def __init__(self): self.deliveries = []
    def deliver(self, d):
        self.deliveries.append(d.record.outbox_id); return f"live:{len(self.deliveries)}"


def seed(tmp, *, total, recipient="admin"):
    bus = SignalBusStore(tmp / "signal-bus.sqlite3")
    records = tuple(RunnerSignalRecord(sequence=i, signal=H._signal("0123456789abcdef"[i % 16]))
                    for i in range(1, total + 1))
    route_runner_signals(
        source_id="n-shape-v1", source=H._Source(records), bus=bus,
        cursors=SignalRouteCursorStore(tmp / "route-cursor.sqlite3", routing_policy_fingerprint=H.POLICY),
        routed_at=H.NOW,
        target_resolver=lambda _s: RoutingDecision.route(
            routing_policy_fingerprint=H.POLICY,
            targets=(DeliveryTarget(recipient_id=recipient, channel=DeliveryChannel.PUSHDEER),)),
        limit=total)
    publish_signal_bus_prefix(bus=bus, spool=SignalRouteSpool(tmp / "signal-spool"), limit=200)


print("=" * 78)
print("A. paused -> live: the storm the DEPLOY note forbids")
with tempfile.TemporaryDirectory(dir="/Users/roxor/rq-aarev") as td:
    tmp = pathlib.Path(td); seed(tmp, total=5)
    store = NotificationStateStore(tmp / "notification-state.sqlite3")
    paused = notifier_builder(provider_loader=lambda: {DeliveryChannel.PUSHDEER: Recorder()},
                              clock=lambda: H.NOW)(H._notifier_manifest(tmp, paused=True, batch_limit=2))
    for _ in range(3):
        r = paused()
    print(f"  after 3 paused rounds: cursor={store.replication_cursor().last_global_sequence}, "
          f"outbox rows={len(store.outbox_records())}, backlog={r.backlog_count}")
    rec = Recorder()
    live = notifier_builder(provider_loader=lambda: {DeliveryChannel.PUSHDEER: rec},
                            clock=lambda: H.NOW + timedelta(seconds=2))(H._notifier_manifest(tmp, batch_limit=128))
    first = live()
    print(f"  FIRST live round claims {first.processed_count} and sends {len(rec.deliveries)} "
          f"-> the whole backlog in one go")

print("=" * 78)
print("B. risk (b): a retried outbox row writes the SAME receipt twice, not two ids")
with tempfile.TemporaryDirectory(dir="/Users/roxor/rq-aarev") as td:
    tmp = pathlib.Path(td); seed(tmp, total=1)
    store = NotificationStateStore(tmp / "notification-state.sqlite3")
    import rquant.signal_bus as sb
    real = sb.SignalBusStore.complete_success
    calls = {"n": 0}
    def flaky(self, *a, **k):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("simulated write-back loss")
        return real(self, *a, **k)
    sb.SignalBusStore.complete_success = flaky
    try:
        step = notifier_builder(provider_loader=lambda: {DeliveryChannel.PUSHDEER: Recorder()},
                                clock=lambda: H.NOW)(H._notifier_manifest(tmp, suppress_delivery=True))
        r1 = step()
        print(f"  round 1: unknown outcome, statuses={dict(Counter(x.status.value for x in store.outbox_records()))}")
        step2 = notifier_builder(provider_loader=lambda: {DeliveryChannel.PUSHDEER: Recorder()},
                                 clock=lambda: H.NOW + timedelta(minutes=1))(H._notifier_manifest(tmp, suppress_delivery=True))
        r2 = step2()
        atts = store.attempts()
        print(f"  round 2: statuses={dict(Counter(x.status.value for x in store.outbox_records()))}")
        print(f"  attempt rows={len(atts)}  attempt_nos={[a.attempt_no for a in atts]}")
        print(f"  distinct receipts across the two attempts = {len({a.provider_receipt for a in atts if a.provider_receipt})}")
        print(f"  receipts: {sorted({a.provider_receipt for a in atts if a.provider_receipt})}")
    finally:
        sb.SignalBusStore.complete_success = real

print("=" * 78)
print("C1. preflight refusal: identical in both modes?")
def registry_for(recipient_with_credential, *, reject=False):
    caps = RecipientNotificationCapabilities(
        {DeliveryChannel.PUSHDEER: {recipient_with_credential: "a-key"}})
    class T:
        def __init__(self): self.calls = []
        def send(self, **kw):
            self.calls.append(kw)
            return (NotificationTransportResult.rejected() if reject
                    else NotificationTransportResult.accepted())
    t = T()
    prov = RecipientScopedNotificationProvider(
        channel=DeliveryChannel.PUSHDEER, endpoint="https://example.invalid/push",
        capabilities=caps, transport=t)
    return RecipientScopedProviderRegistry(
        providers={DeliveryChannel.PUSHDEER: prov},
        recipient_ids={DeliveryChannel.PUSHDEER: (recipient_with_credential,)}), t

for mode, kwargs in (("live", {}), ("shadow", {"suppress_delivery": True})):
    with tempfile.TemporaryDirectory(dir="/Users/roxor/rq-aarev") as td:
        tmp = pathlib.Path(td)
        seed(tmp, total=1, recipient="admin.ghost")   # no credential for this id
        store = NotificationStateStore(tmp / "notification-state.sqlite3")
        reg, t = registry_for("admin.iphone")
        step = notifier_builder(provider_loader=lambda: reg,
                                clock=lambda: H.NOW)(H._notifier_manifest(tmp, **kwargs))
        try:
            step(); print(f"  {mode:6s}: NO REFUSAL (masked!)")
        except Exception as e:
            print(f"  {mode:6s}: {type(e).__name__}: {e}")

print("=" * 78)
print("C2. a provider that REJECTS on the wire: live records the failure, shadow cannot")
for mode, kwargs in (("live", {}), ("shadow", {"suppress_delivery": True})):
    with tempfile.TemporaryDirectory(dir="/Users/roxor/rq-aarev") as td:
        tmp = pathlib.Path(td)
        seed(tmp, total=1, recipient="admin.iphone")
        store = NotificationStateStore(tmp / "notification-state.sqlite3")
        reg, t = registry_for("admin.iphone", reject=True)
        step = notifier_builder(provider_loader=lambda: reg,
                                clock=lambda: H.NOW)(H._notifier_manifest(tmp, **kwargs))
        r = step()
        rows = store.outbox_records(); atts = store.attempts()
        print(f"  {mode:6s}: outbox={[x.status.value for x in rows]} "
              f"attempt.success={[a.success for a in atts]} "
              f"receipt={[a.provider_receipt for a in atts]} "
              f"degraded={r.degraded_reasons} transport_calls={len(t.calls)}")

print("=" * 78)
print("D. loader failure and missing capability: must raise in shadow exactly as in live")
class Boom(RuntimeError): pass
for mode, kwargs in (("live", {}), ("shadow", {"suppress_delivery": True})):
    with tempfile.TemporaryDirectory(dir="/Users/roxor/rq-aarev") as td:
        tmp = pathlib.Path(td); seed(tmp, total=1)
        def boom(): raise Boom("capability store unreadable")
        step = notifier_builder(provider_loader=boom,
                                clock=lambda: H.NOW)(H._notifier_manifest(tmp, **kwargs))
        try:
            step(); print(f"  {mode:6s}: NO RAISE (masked!)")
        except Exception as e:
            print(f"  {mode:6s}: {type(e).__name__}: {e}")
