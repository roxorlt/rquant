set -uo pipefail
cd /Users/roxor/brain/30-projects/rQuant/.worktrees/ra-z-cc
source /Users/roxor/rq-z-root/env.sh
export PYTHONDONTWRITEBYTECODE=1
NAME="$1"; FILE="$2"; FROM="$3"; TO="$4"; SEL="$5"
python3 - "$FILE" "$FROM" "$TO" <<'PY'
import sys
path, frm, to = sys.argv[1], sys.argv[2], sys.argv[3]
s = open(path).read()
assert s.count(frm) == 1, (path, frm, s.count(frm))
open(path, "w").write(s.replace(frm, to))
PY
OUT=$(.venv/bin/python -m pytest tests/integration/test_route_a_trading_day_full_chain_e2e.py \
      --basetemp="$TMPDIR/pt-mut" -q -k "$SEL" -p no:randomly 2>&1 | tail -3)
git checkout -- "$FILE"
echo "MUTATION[$NAME]: $(echo "$OUT" | grep -oE '[0-9]+ (passed|failed)[^ ]*' | tr '\n' ' ')"
