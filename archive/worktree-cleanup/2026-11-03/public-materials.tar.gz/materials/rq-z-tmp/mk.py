import sys, hashlib
from datetime import date, datetime, timedelta
from pathlib import Path
sys.path.insert(0, "/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-z-cc/scripts")
sys.path.insert(0, "/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-z-cc/src")
import duckdb, pandas as pd
from export_intraday_snapshot import read_snapshot_frame, write_snapshot

root = Path("/Users/roxor/rq-z-tmp/mh"); root.mkdir(exist_ok=True)
db = root / "rquant_ro.duckdb"
if db.exists(): db.unlink()
con = duckdb.connect(str(db))
con.execute("""CREATE TABLE minute_bar (ts_code VARCHAR NOT NULL, trade_time TIMESTAMP NOT NULL,
 freq VARCHAR NOT NULL, open DOUBLE, high DOUBLE, low DOUBLE, close DOUBLE, vol DOUBLE, amount DOUBLE,
 source VARCHAR DEFAULT 'tushare', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 PRIMARY KEY (ts_code, trade_time, freq, source));""")
rows = []
CODES = ("600000.SH", "600519.SH", "000001.SZ")
for day in (date(2026,7,30), date(2026,7,31)):
    for i, code in enumerate(CODES):
        base = 10.0 + i
        for m in range(30):   # 09:31..10:00
            t = datetime(day.year, day.month, day.day, 9, 31) + timedelta(minutes=m)
            close = base + 0.01*m
            rows.append((code, t, "1min", close-0.01, close+0.02, close-0.02, close, 1000.0+10*m, (1000.0+10*m)*close, "tushare"))
con.executemany("INSERT INTO minute_bar (ts_code,trade_time,freq,open,high,low,close,vol,amount,source) VALUES (?,?,?,?,?,?,?,?,?,?)", rows)
con.close()

frame, dates = read_snapshot_frame(db, sessions=2, source="tushare", freq="1min",
                                   availability_lag_seconds=0, allow_primary_database=False)
out = root / "minute-history.parquet"
digest = write_snapshot(frame, out)
print("rows", len(frame), "codes", frame.ts_code.nunique(), "sessions", [d.isoformat() for d in dates])
print("sha", digest, "bytes", out.stat().st_size)
print(frame.head(3).to_string())
