from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_capabilities.py")
t = p.read_text(encoding="utf-8")
old = "        if required or credential_directory:"
new = "        if credential_directory:"
assert old in t
p.write_text(t.replace(old, new, 1), encoding="utf-8")
