from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_authority.py")
t = p.read_text(encoding="utf-8")
n = t.count("        _RUNTIME_ROLE_ENVIRONMENT,\n")
t = t.replace("        _RUNTIME_ROLE_ENVIRONMENT,\n", "        _CAPABILITY_ROLE_ENVIRONMENT,\n")
print("widened", n, "roles")
p.write_text(t, encoding="utf-8")
