from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_service_control.py")
t = p.read_text(encoding="utf-8")
old = """                and heartbeat.stopped_at is not None
                and (owns_service_lock or not cls._service_lock_is_held(root, spec))
            )"""
new = """                and heartbeat.stopped_at is not None
            )"""
assert old in t
p.write_text(t.replace(old, new, 1), encoding="utf-8")
