from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/adapter/tushare.py")
t = p.read_text(encoding="utf-8")
anchor = "from rquant.trade_calendar import normalize_trade_calendar\n"
assert anchor in t
t = t.replace(anchor, anchor.rstrip("\n") + "\nfrom rquant.config import settings\n", 1)
old = """        self._primary_token = token or _settings().tushare_token_main
        self._backup_token = (
            backup_token if backup_token is not None else _settings().tushare_token_backup
        )"""
new = """        self._primary_token = token or settings.tushare_token_main
        self._backup_token = (
            backup_token if backup_token is not None else settings.tushare_token_backup
        )"""
assert old in t
p.write_text(t.replace(old, new, 1), encoding="utf-8")
