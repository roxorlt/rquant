from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_service_control.py")
t = p.read_text(encoding="utf-8")
old = """            superseded = (
                heartbeat.status is RuntimeServiceStatus.STOPPED"""
new = """            superseded = False and (
                heartbeat.status is RuntimeServiceStatus.STOPPED"""
assert old in t
p.write_text(t.replace(old, new, 1), encoding="utf-8")
