from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_authority.py")
t = p.read_text(encoding="utf-8")
t = t.replace('_CAPABILITY_ROLE_ENVIRONMENT = ("CREDENTIALS_DIRECTORY", *_RUNTIME_ROLE_ENVIRONMENT)',
              '_CAPABILITY_ROLE_ENVIRONMENT = _RUNTIME_ROLE_ENVIRONMENT', 1)
p.write_text(t, encoding="utf-8")
