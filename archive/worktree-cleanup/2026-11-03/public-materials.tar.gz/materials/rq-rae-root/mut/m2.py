from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/notify/log.py")
t = p.read_text(encoding="utf-8")
t = t.replace("from typing import Any\n", "from typing import Any\n\nfrom rquant.config import settings\n", 1)
t = t.replace('return _settings().log_dir / "notification_log.jsonl"', 'return settings.log_dir / "notification_log.jsonl"', 1)
p.write_text(t, encoding="utf-8")
