from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_builder_daily.py")
t = p.read_text(encoding="utf-8")
old = """    adapter: DailyCloseRuntimeAdapter = (
        TushareAdapter(token=token, backup_token=backup_token)
        if transport_observer is None
        else TushareAdapter(
            token=token,
            backup_token=backup_token,
            transport_observer=transport_observer,
        )
    )"""
new = """    adapter: DailyCloseRuntimeAdapter = (
        TushareAdapter(token=token)
        if transport_observer is None
        else TushareAdapter(token=token, transport_observer=transport_observer)
    )"""
assert old in t
p.write_text(t.replace(old, new, 1), encoding="utf-8")
