from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_capabilities.py")
t = p.read_text(encoding="utf-8")
old = """        reason = _undelivered_credential_reason() if required else None
        if reason is not None:"""
new = """        reason = None
        if reason is not None:"""
assert old in t
p.write_text(t.replace(old, new, 1), encoding="utf-8")
