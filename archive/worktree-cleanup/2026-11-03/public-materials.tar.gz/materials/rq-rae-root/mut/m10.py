from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_capabilities.py")
t = p.read_text(encoding="utf-8")
# Put the Route B branch back ahead of the delivery diagnosis, and let a capability kind
# with nothing in reach degrade again -- the shape the review found.
diagnosis_start = t.index("    if not credential_directory and required:")
route_b_start = t.index("    if expected_generation is None:")
route_b_end = t.index("    if re.fullmatch(r\"[0-9a-f]{64}\", expected_generation) is None:")
diagnosis = t[diagnosis_start:route_b_start]
route_b = t[route_b_start:route_b_end]
route_b = route_b.replace("        if required or credential_directory:", "        if credential_directory:", 1)
p.write_text(t[:diagnosis_start] + route_b + diagnosis + t[route_b_end:], encoding="utf-8")
