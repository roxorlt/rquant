from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/src/rquant/runtime_service_main.py")
t = p.read_text(encoding="utf-8")
old = """        expected_instance=instance,
        expected_generation=schema_generation,
    )"""
new = """        expected_instance=instance,
        expected_generation=args.expected_generation,
    )"""
assert old in t
p.write_text(t.replace(old, new, 1), encoding="utf-8")
