import hashlib, json, sys
sys.path.insert(0, "src")
from rquant.runtime_authority import PRODUCTION_ROLE_POLICY
from rquant.runtime_capabilities import CAPABILITY_KEYS

CAP = {k.value for k in CAPABILITY_KEYS}

def digest(strip: bool) -> str:
    body = []
    for e in PRODUCTION_ROLE_POLICY:
        names = list(e.environment_allowlist)
        if strip and e.service_kind in CAP:
            names = [n for n in names if n != "CREDENTIALS_DIRECTORY"]
        body.append({
            "name": e.name, "module": e.module, "environment_allowlist": names,
            "service_kind": e.service_kind, "control_root": e.control_root,
            "once": e.once, "module_arguments": list(e.module_arguments),
        })
    return hashlib.sha256(json.dumps(body, separators=(",", ":"), sort_keys=True).encode()).hexdigest()

print("roles-digest before (origin/main shape):", digest(True))
print("roles-digest after  (this branch)      :", digest(False))
