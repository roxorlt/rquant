#!/usr/bin/env bash
# One mutation: apply, run the named tests, record verbatim, revert.
# usage: mutate.sh <label> <python-patch-file> <pytest-args...>
set -uo pipefail
cd /Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc
source /Users/roxor/rq-rae-root/env.sh
label="$1"; patch="$2"; shift 2
out="/Users/roxor/rq-rae-root/mut-${label}.log"

git diff --quiet && git diff --cached --quiet || { echo "worktree dirty, refusing"; exit 9; }
python3 "$patch" || { echo "patch failed"; exit 9; }
git --no-pager diff --stat | tail -3
.venv/bin/python -m pytest "$@" -q -p no:cacheprovider > "$out" 2>&1
rc=$?
git checkout -- .
echo "rc=${rc}"
grep -E "^(FAILED|ERROR)|assert|Error|[0-9]+ (passed|failed)" "$out" | tail -12
