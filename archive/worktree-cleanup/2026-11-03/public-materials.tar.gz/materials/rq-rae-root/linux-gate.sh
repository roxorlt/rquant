#!/usr/bin/env bash
# Package E Linux gate: the credstore roles over a credential the real sealer encrypted.
set -euo pipefail

export DEBIAN_FRONTEND=noninteractive
apt-get update -qq >/dev/null
apt-get install -y -qq systemd git ca-certificates >/dev/null
command -v systemd-creds >/dev/null || { echo "no systemd-creds"; exit 3; }

mkdir -p /work
cp -a /src/. /work/
rm -rf /work/.venv /work/.git
cd /work

python -m pip install -q uv==0.10.11
uv sync --frozen >/dev/null

root=/root/rq-e
umask 077
mkdir -p "${root}/tmp" "${root}/data" "${root}/parquet" "${root}/logs"
chmod 700 "${root}" "${root}/tmp" "${root}/data" "${root}/parquet" "${root}/logs"
export TMPDIR="${root}/tmp" TMP="${root}/tmp" TEMP="${root}/tmp"
export DATA_DIR="${root}/data"
export DUCKDB_PATH="${root}/data/test.duckdb"
export DUCKDB_READONLY_PATH="${root}/data/test-ro.duckdb"
export PARQUET_DIR="${root}/parquet"
export LOG_DIR="${root}/logs"
export RQUANT_DISABLE_DOTENV=1
export TUSHARE_TOKEN_MAIN=00000000000000000000000000000000
export NOTIFY_ENABLED=false

git config --global user.email ci@example.invalid
git config --global user.name ci
git config --global init.defaultBranch main

echo "=== systemd-creds present ==="
systemd-creds --version | head -1
echo "=== linux_exact gate ==="
.venv/bin/python -m pytest \
  tests/integration/test_route_a_credstore_roles_e2e.py \
  -m linux_exact -p no:cacheprovider -q
echo "=== whole credstore file, portable plus gate ==="
.venv/bin/python -m pytest \
  tests/integration/test_route_a_credstore_roles_e2e.py \
  -m 'not network' -p no:cacheprovider -q
echo "=== the unit files this package touches ==="
.venv/bin/python -m pytest \
  tests/unit/test_credstore_capability_delivery.py \
  tests/unit/test_credstore_role_child_environment.py \
  tests/unit/test_runtime_heartbeat_supersede.py \
  tests/unit/test_runtime_credential_sealer_helper.py \
  tests/unit/test_daily_close_gateway.py \
  tests/unit/test_tp9_role_child_runtime.py \
  tests/unit/test_runtime_capabilities.py \
  tests/unit/test_runtime_service_control.py \
  -p no:cacheprovider -q
echo "LINUX-GATE-OK"
