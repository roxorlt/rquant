"""Pin _observe_scale to 1.0 so the cases run at Codex's literal numbers
(hold 0.200s, receipt budget 0.010s) instead of this host's spawn scale."""
def pytest_runtest_call(item):
    module = getattr(item, "module", None)
    if module is not None and hasattr(module, "_observe_scale"):
        module._observe_scale = 1.0
