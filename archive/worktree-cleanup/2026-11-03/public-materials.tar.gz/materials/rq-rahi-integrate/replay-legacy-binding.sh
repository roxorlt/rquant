set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq >/dev/null
apt-get install -y -qq --no-install-recommends ca-certificates git openssh-client openssl >/dev/null
python -m pip install -q uv==0.10.11
useradd -m -u 1000 runner
# the job's `sudo install -d -m 0755 -o "$(id -u)" -g "$(id -g)" /home/lighthouse`
install -d -m 0755 -o 1000 -g 1000 /home/lighthouse
cp -a /repo /work
chown -R runner:runner /work
su runner -s /bin/bash -c '
set -euo pipefail
umask 077
export HOME=/home/runner
export RQUANT_DISABLE_DOTENV=1
export TUSHARE_TOKEN_MAIN=00000000000000000000000000000000
export NOTIFY_ENABLED=false
exact_root="${HOME}/rquant-route-a-py3.11"
mkdir -p "${exact_root}/data" "${exact_root}/parquet" "${exact_root}/logs"
mkdir -p "${exact_root}/pytest" "${exact_root}/test-results"
chmod 700 "${exact_root}" "${exact_root}/data" "${exact_root}/parquet"
chmod 700 "${exact_root}/logs" "${exact_root}/pytest" "${exact_root}/test-results"
export RQUANT_ROUTE_A_ROOT="${exact_root}"
export DATA_DIR="${exact_root}/data"
export DUCKDB_PATH="${exact_root}/data/main.duckdb"
export DUCKDB_READONLY_PATH="${exact_root}/data/readonly.duckdb"
export PARQUET_DIR="${exact_root}/parquet"
export LOG_DIR="${exact_root}/logs"
cd /work
uv sync --frozen -q
junit="${RQUANT_ROUTE_A_ROOT}/test-results/route-a-legacy-binding.xml"
uv run python -m pytest -o addopts= --strict-markers -m linux_exact -rA \
  --basetemp="${RQUANT_ROUTE_A_ROOT}/pytest" \
  --junitxml="${junit}" \
  tests/integration/test_route_a_legacy_binding_e2e.py
uv run python tests/support/assert_junit_contract.py \
  --path "${junit}" \
  --suites 1 --tests 1 --failures 0 --errors 0 --skipped 0 --cases 1
grep -q "test_the_wrapper_argv_runs_verbatim_against_the_frozen_production_root" "${junit}"
echo "CI-CONTRACT-OK route-a-legacy-binding-linux py3.11"
'
