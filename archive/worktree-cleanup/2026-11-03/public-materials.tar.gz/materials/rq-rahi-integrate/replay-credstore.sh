set -euo pipefail
export DEBIAN_FRONTEND=noninteractive
apt-get update -qq >/dev/null
apt-get install -y -qq --no-install-recommends systemd git ca-certificates openssh-client >/dev/null
cp -a /repo /work
export RQUANT_DISABLE_DOTENV=1
export TUSHARE_TOKEN_MAIN=00000000000000000000000000000000
export NOTIFY_ENABLED=false
umask 077
exact_root="/rquant-credstore-py3.11"
mkdir -p "${exact_root}/data" "${exact_root}/parquet" "${exact_root}/logs"
mkdir -p "${exact_root}/pytest" "${exact_root}/test-results"
chmod 700 "${exact_root}" "${exact_root}/data" "${exact_root}/parquet"
chmod 700 "${exact_root}/logs" "${exact_root}/pytest" "${exact_root}/test-results"
export RQUANT_CREDSTORE_ROOT="${exact_root}"
export DATA_DIR="${exact_root}/data"
export DUCKDB_PATH="${exact_root}/data/main.duckdb"
export DUCKDB_READONLY_PATH="${exact_root}/data/readonly.duckdb"
export PARQUET_DIR="${exact_root}/parquet"
export LOG_DIR="${exact_root}/logs"
python -m pip install -q --root-user-action=ignore uv==0.10.11
cd /work
uv sync --frozen -q
test "$(id -u)" -eq 0
/usr/bin/systemd-creds --version | head -1
systemd-analyze has-tpm2 || true
junit="${RQUANT_CREDSTORE_ROOT}/test-results/route-a-credstore.xml"
uv run python -m pytest -o addopts= --strict-markers -m linux_exact -rA \
  --basetemp="${RQUANT_CREDSTORE_ROOT}/pytest" \
  --junitxml="${junit}" \
  tests/integration/test_route_a_credstore_roles_e2e.py
uv run python tests/support/assert_junit_contract.py \
  --path "${junit}" \
  --suites 1 --tests 1 --failures 0 --errors 0 --skipped 0 --cases 1
grep -q "test_the_roles_run_off_a_credential_the_real_sealer_encrypted" "${junit}"
echo "CI-CONTRACT-OK route-a-credstore-linux py3.11"
