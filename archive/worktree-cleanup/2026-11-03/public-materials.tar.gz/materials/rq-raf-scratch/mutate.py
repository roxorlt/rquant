import subprocess
import sys
from pathlib import Path

ROOT = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-f-cc")

MUTATIONS = {
    "M1": (
        "src/rquant/runtime_service_main.py",
        '        raw = item.model_dump(mode="json") if isinstance(item, RuntimeServiceManifest) else item\n        try:\n            profile_manifests.append(RuntimeServiceManifest.model_validate(raw))\n',
        '        try:\n            profile_manifests.append(RuntimeServiceManifest.model_validate(item))\n',
    ),
    "M2": (
        "src/rquant/runtime_recovery_production.py",
        '    recovery = profile.recovery  # type: ignore[attr-defined]\n    generation = str(recovery.profile_generation)\n',
        '    return  # MUTANT: no binding at all\n    recovery = profile.recovery  # type: ignore[attr-defined]\n    generation = str(recovery.profile_generation)\n',
    ),
    "M3": (
        "src/rquant/runtime_recovery_production.py",
        '    if generation != bundle_recovery_profile_generation(profile):\n        raise ValueError("recovery unit profile generation is stale")\n',
        '    if expected_generation is not None and generation != str(expected_generation):\n        raise ValueError("recovery unit profile generation is stale")\n',
    ),
    "M4": (
        "src/rquant/runtime_recovery_production.py",
        '    if manifest_path is None:\n        return\n    if expected_generation is None:\n',
        '    return  # MUTANT: recovery namespace only, no authority binding\n    if expected_generation is None:\n',
    ),
    "M6": (
        "scripts/provision_runtime_recovery_credentials.py",
        '    if state == "absent":\n        return True\n    if state == "private":\n        return False\n',
        '    if state != "private":\n        return True\n    return False\n',
    ),
    "M5": (
        "scripts/provision_runtime_recovery_credentials.py",
        '    if len(bytes.fromhex(minted)) < MINIMUM_SECRET_BYTES:\n        raise ProvisionError("recovery credential secret must contain at least 32 bytes")\n',
        '',
    ),
}


def apply(name: str) -> None:
    relative, old, new = MUTATIONS[name]
    path = ROOT / relative
    text = path.read_text()
    assert old in text, f"{name}: anchor not found in {relative}"
    path.write_text(text.replace(old, new, 1))


def restore() -> None:
    subprocess.run(["git", "-C", str(ROOT), "checkout", "--", "src", "scripts"], check=True)


if __name__ == "__main__":
    if sys.argv[1] == "restore":
        restore()
    else:
        apply(sys.argv[1])
    print("ok")
