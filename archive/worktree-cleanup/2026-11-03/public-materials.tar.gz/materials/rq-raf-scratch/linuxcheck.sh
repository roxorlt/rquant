set -euo pipefail
mkdir -p /work/src-copy
cp -a /src/. /work/src-copy/
cd /work/src-copy
rm -rf .venv .pytest_cache
rm -rf .git
export RQUANT_DISABLE_DOTENV=1
export TUSHARE_TOKEN_MAIN=00000000000000000000000000000000
export NOTIFY_ENABLED=false
mkdir -p /work/root/tmp /work/root/data /work/root/parquet /work/root/logs
chmod 700 /work/root /work/root/tmp /work/root/data /work/root/parquet /work/root/logs
export TMPDIR=/work/root/tmp TMP=/work/root/tmp TEMP=/work/root/tmp
export DATA_DIR=/work/root/data
export DUCKDB_PATH=/work/root/data/test.duckdb
export DUCKDB_READONLY_PATH=/work/root/data/test_ro.duckdb
export PARQUET_DIR=/work/root/parquet
export LOG_DIR=/work/root/logs
export PYTHONPATH=/work/src-copy/src
git config --global user.email t@example.com
git config --global user.name t
git config --global init.defaultBranch main
/opt/venv/bin/python -m pytest -q -p no:randomly --basetemp=/work/root/tmp/pt \
  tests/unit/test_runtime_service_manifest_revalidation.py \
  tests/unit/test_runtime_recovery_generation_binding.py \
  tests/unit/test_provision_runtime_recovery_credentials.py \
  tests/integration/test_route_a_strategy_chain_e2e.py \
  tests/integration/test_route_a_recovery_binding_e2e.py
