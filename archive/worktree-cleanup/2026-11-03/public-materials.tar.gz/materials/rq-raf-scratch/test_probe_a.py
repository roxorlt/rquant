from __future__ import annotations

from pathlib import Path
from typing import Any

import pytest

import rquant.runtime_service_main as service_main
from rquant.runtime_service_entrypoint import RuntimeServiceKind
from tests.integration.test_route_a_legacy_binding_e2e import RouteAWorld, _route_a_world

pytestmark = pytest.mark.integration


@pytest.fixture
def route_a(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> RouteAWorld:
    route = _route_a_world(tmp_path, monkeypatch)
    route.stage_and_publish()
    return route


def test_probe_signer(route_a: RouteAWorld) -> None:
    strategies = [
        m for m in route_a.profile.manifests
        if m.service_kind is RuntimeServiceKind.STRATEGY_LIVE
    ]
    print("strategy manifests:", len(strategies))
    nested = [
        m.service_id
        for m in route_a.profile.manifests
        if any(not isinstance(v, (str, int, float, bool, type(None))) for v in m.settings.values())
    ]
    print("manifests with nested settings:", len(nested))
    signer, key_id = service_main.build_runtime_strategy_completion_attestation_signer(
        route_a.runtime_root, manifest=strategies[0]
    )
    print("built", key_id)


def test_probe_run_role(route_a: RouteAWorld) -> None:
    print("instances:", route_a.world.instances(route_a.plan).get("strategy_live"))
    labels = route_a.world.instances(route_a.plan)["strategy_live"]
    argv = list(route_a.world.resolve("strategy_live", labels[0])["module_argv"])
    index = argv.index("--control-root") + 1
    from tests.integration.test_route_a_legacy_binding_e2e import PRODUCTION_ROOT
    argv[index] = str(route_a.runtime_root / Path(argv[index]).relative_to(PRODUCTION_ROOT))
    print("argv:", argv)
    assert route_a.run_role("strategy_live", argv=argv) == 0
