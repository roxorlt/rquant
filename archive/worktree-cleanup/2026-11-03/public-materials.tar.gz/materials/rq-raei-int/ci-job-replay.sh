#!/usr/bin/env bash
# Replays, as root in a python:3.11-slim container, exactly the steps the
# route-a-credstore-linux CI job runs.
set -euo pipefail

# --- step: Install systemd and the checkout prerequisites -------------------
apt-get update -qq
apt-get install -y -qq --no-install-recommends systemd git ca-certificates openssh-client

# --- step: actions/checkout (replayed as a copy of the worktree) ------------
mkdir -p /work
cp -a /src/. /work/
cd /work
rm -rf .venv .venv312

# --- step: Create the private credstore test root ---------------------------
umask 077
exact_root="${RUNNER_TEMP}/rquant-credstore-py3.11"
mkdir -p "${exact_root}/data" "${exact_root}/parquet" "${exact_root}/logs"
mkdir -p "${exact_root}/pytest" "${exact_root}/test-results"
chmod 700 "${exact_root}" "${exact_root}/data" "${exact_root}/parquet"
chmod 700 "${exact_root}/logs" "${exact_root}/pytest" "${exact_root}/test-results"
export RQUANT_CREDSTORE_ROOT="${exact_root}"
export DATA_DIR="${exact_root}/data"
export DUCKDB_PATH="${exact_root}/data/main.duckdb"
export DUCKDB_READONLY_PATH="${exact_root}/data/readonly.duckdb"
export PARQUET_DIR="${exact_root}/parquet"
export LOG_DIR="${exact_root}/logs"

# --- step: Install uv -------------------------------------------------------
python -m pip install --quiet --root-user-action=ignore uv==0.10.11

# --- step: Install locked dependencies --------------------------------------
uv sync --frozen

# --- evidence: the container is the shape the production host has -----------
id -u
/usr/bin/systemd-creds --version | head -1
systemd-analyze has-tpm2 || true

# --- step: Run the Linux-only credstore role case ---------------------------
junit="${RQUANT_CREDSTORE_ROOT}/test-results/route-a-credstore.xml"
uv run python -m pytest -o addopts='' --strict-markers -m linux_exact -rA \
  --basetemp="${RQUANT_CREDSTORE_ROOT}/pytest" \
  --junitxml="${junit}" \
  tests/integration/test_route_a_credstore_roles_e2e.py

# --- step: Verify the gate ran that one case and skipped nothing ------------
uv run python tests/support/assert_junit_contract.py \
  --path "${junit}" \
  --suites 1 --tests 1 --failures 0 --errors 0 --skipped 0 --cases 1
grep -q 'test_the_roles_run_off_a_credential_the_real_sealer_encrypted' "${junit}"
echo "REPLAY OK"
