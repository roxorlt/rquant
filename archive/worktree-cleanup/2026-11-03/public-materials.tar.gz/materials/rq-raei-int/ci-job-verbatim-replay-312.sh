#!/usr/bin/env bash
# Generated from .github/workflows/ci.yml job route-a-credstore-linux. Every `run:` block
# is reproduced verbatim and in order, matrix leg pinned to 3.12. The surrounding
# container is shaped like a GitHub container job: /__w owned by the host runner uid,
# RUNNER_TEMP under it, the workspace checked out as root.
set -euo pipefail
export GITHUB_ENV="${RUNNER_TEMP}/github_env"
: > "${GITHUB_ENV}"
export RQUANT_DISABLE_DOTENV="1"
export TUSHARE_TOKEN_MAIN="00000000000000000000000000000000"
export NOTIFY_ENABLED="false"

# ---- step: Install systemd and the checkout prerequisites
set -a; source "${GITHUB_ENV}"; set +a
set -euo pipefail
apt-get update -qq
apt-get install -y -qq --no-install-recommends \
  systemd git ca-certificates openssh-client
set -a; source "${GITHUB_ENV}"; set +a

# ---- step: actions/checkout@11d5960a326750d5838078e36cf38b85af677262
mkdir -p "${GITHUB_WORKSPACE}"
cp -a /src/. "${GITHUB_WORKSPACE}/"
cd "${GITHUB_WORKSPACE}"
rm -rf .venv .venv312 ci-evidence

# ---- step: Create the private credstore test root
set -a; source "${GITHUB_ENV}"; set +a
set -euo pipefail
umask 077
exact_root="/rquant-credstore-py3.12"
mkdir -p "${exact_root}/data" "${exact_root}/parquet" "${exact_root}/logs"
mkdir -p "${exact_root}/pytest" "${exact_root}/test-results"
chmod 700 "${exact_root}" "${exact_root}/data" "${exact_root}/parquet"
chmod 700 "${exact_root}/logs" "${exact_root}/pytest" "${exact_root}/test-results"
{
  printf 'RQUANT_CREDSTORE_ROOT=%s\n' "${exact_root}"
  printf 'DATA_DIR=%s/data\n' "${exact_root}"
  printf 'DUCKDB_PATH=%s/data/main.duckdb\n' "${exact_root}"
  printf 'DUCKDB_READONLY_PATH=%s/data/readonly.duckdb\n' "${exact_root}"
  printf 'PARQUET_DIR=%s/parquet\n' "${exact_root}"
  printf 'LOG_DIR=%s/logs\n' "${exact_root}"
} >> "${GITHUB_ENV}"
set -a; source "${GITHUB_ENV}"; set +a

# ---- step: Install uv
set -a; source "${GITHUB_ENV}"; set +a
python -m pip install --root-user-action=ignore uv==0.10.11
set -a; source "${GITHUB_ENV}"; set +a

# ---- step: Install locked dependencies
set -a; source "${GITHUB_ENV}"; set +a
uv sync --frozen
set -a; source "${GITHUB_ENV}"; set +a

# ---- step: Record that the container really is root with a real systemd-creds
set -a; source "${GITHUB_ENV}"; set +a
set -euo pipefail
test "$(id -u)" -eq 0
/usr/bin/systemd-creds --version | head -1
# `partial` on a machine without a TPM, which is also what the production host
# reports; the sealer does not need one.
systemd-analyze has-tpm2 || true
set -a; source "${GITHUB_ENV}"; set +a

# ---- step: Run the Linux-only credstore role case
set -a; source "${GITHUB_ENV}"; set +a
set -euo pipefail
junit="${RQUANT_CREDSTORE_ROOT}/test-results/route-a-credstore.xml"
uv run python -m pytest -o addopts='' --strict-markers -m linux_exact -rA \
  --basetemp="${RQUANT_CREDSTORE_ROOT}/pytest" \
  --junitxml="${junit}" \
  tests/integration/test_route_a_credstore_roles_e2e.py
set -a; source "${GITHUB_ENV}"; set +a

# ---- step: Verify the gate ran that one case and skipped nothing
set -a; source "${GITHUB_ENV}"; set +a
set -euo pipefail
# A skip here would mean the container lost root or systemd-creds, which is exactly
# the failure mode that made this a separate job.
uv run python tests/support/assert_junit_contract.py \
  --path "${RQUANT_CREDSTORE_ROOT}/test-results/route-a-credstore.xml" \
  --suites 1 --tests 1 --failures 0 --errors 0 --skipped 0 --cases 1
grep -q 'test_the_roles_run_off_a_credential_the_real_sealer_encrypted' \
  "${RQUANT_CREDSTORE_ROOT}/test-results/route-a-credstore.xml"
set -a; source "${GITHUB_ENV}"; set +a

# ---- step: Collect the JUnit evidence into the workspace
set -a; source "${GITHUB_ENV}"; set +a
set -euo pipefail
mkdir -p "${GITHUB_WORKSPACE}/ci-evidence"
cp -a "${RQUANT_CREDSTORE_ROOT}/test-results/." "${GITHUB_WORKSPACE}/ci-evidence/"
set -a; source "${GITHUB_ENV}"; set +a

# ---- step: Upload the Route A credstore JUnit evidence
echo 'action step not replayable locally: actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02'
ls -l "${GITHUB_WORKSPACE}/ci-evidence"

echo 'REPLAY OK'
