Fixes #215. Fixes #216.

Package E of the route A rollout: the eight reviewed commits, a `--no-ff` merge of
`origin/main` (`a90f927`), then seven integration commits.

## What changed

**#215 — the seven credstore roles could not start under the wrapper.** In the 2026-09-07
window all seven ran 0/7, and because `reference_slow_publisher` is one of them there was
no serving generation at all and the second gate could not be scheduled. Three independent
code defects, with `deploy/systemd/` correct throughout:

1. **Delivery stopped at the wrapper allowlist.** systemd puts the decrypted credential's
   path in `$CREDENTIALS_DIRECTORY` and hands it to the unit's ExecStart — the wrapper —
   which starts from an empty environment and copies only the names the profile allows.
   `_RUNTIME_ROLE_ENVIRONMENT` did not carry `CREDENTIALS_DIRECTORY`, so the address was
   dropped silently and the symptom surfaced downstream as `TUSHARE_TOKEN_MAIN capability
   is required` and `requires its isolated publication credential`. The seven capability
   roles now take a separate `_CAPABILITY_ROLE_ENVIRONMENT` — exactly that one extra name —
   and the other 21 roles are pinned unchanged by an exact-tuple assertion.
2. **Two generation namespaces.** The credential is sealed under the *deployment bundle*
   generation and was checked against the *authority chain* generation, which by
   construction can never be equal (the same class of error as #207). The capability load
   moved after generation resolution and now uses `schema_generation`; route B, which has
   no bundle, refuses instead of degrading.
3. **`Settings` still built at import time inside the allowlisted environment.**
   `adapter/tushare.py`, `notify/api.py` and `notify/log.py` are lazy now, the same shape
   TP9 used for #189, plus a fourth site where `runtime_builder_daily` omitted
   `backup_token` and `None` is precisely the "go ask `Settings`" signal.

**#216 — a superseded heartbeat blocked the next generation.** `read_heartbeat` refused any
heartbeat whose `spec_fingerprint` differed, and every spec change leaves one behind, so
after sequence 3 both `runtime_health_publisher` and `serving_publisher` failed to start
and needed a file moved by hand. A heartbeat that is `status=stopped`, carries a
`stopped_at`, and whose service singleton `flock` is held by nobody is now superseded and
overwritten by the next `start()`. A live process, or one that never reached `stop()`, is
still refused. Runbook step R-14 is obsolete.

**Acceptance** is a Linux end-to-end run over a really installed bundle: the real sealer,
the real `/usr/bin/systemd-creds` round trip, then the six roles entering the service loop
one iteration each in the environment the allowlist actually produces. Removing the
credential, handing over a wrong-generation credential, and handing a role its neighbour's
credential are each refused explicitly.

**Integration commits.** The four-shard manifest regenerated for the 60 new collected cases
(13800 → 13860; the `linux_exact` case belongs to no shard, so without this the contract
job and all four shard jobs would have failed with `full-suite collection differs:
missing=60`); a new root-container CI job for that one Linux case; the package E SDD notes
taken back out of the tree the way `5cd72ba` did for package A; one DEPLOY.md wording
alignment; and the R07 refreeze last.

**New CI job `route-a-credstore-linux`.** It cannot be a step inside
`route-a-legacy-binding-linux`: that job runs as the unprivileged `runner`, while
`systemd-creds encrypt` needs root for `/var/lib/systemd/credential.secret`, so the case
would have skipped and that job's JUnit contract passes `--skipped 0`. A
`python:<version>-slim` container supplies root and systemd together. Its private root sits
straight off `/` rather than under `RUNNER_TEMP`, because `assert_safe_ancestor` walks every
ancestor up to `/` and in a container job `RUNNER_TEMP` is `/__w/_temp`, whose `/__w`
belongs to the host runner's uid — verified both ways locally, `deployment lock ancestor
/__w is unsafe` against a pass. Replayed verbatim in local containers on both matrix legs:
1 passed in 14.97 s on 3.11 and 15.82 s on 3.12, contract and grep green, `systemd-creds`
257 with `has-tpm2` reporting `partial`, the shape the production host reported.

## Review verdict

**Conditional pass**, then two follow-up rounds. Review at
`/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-e-cc/.superpowers/sdd/2026-09-07-credstore-roles/pkgE-review.md`
(kept out of the repository, like every other SDD note). The reviewer re-ran every claim
independently, including nine mutations and a Linux container end-to-end, and found nothing
that had to change in the code.

- **M-1 (must-fix, documentation, consequence "cannot roll back"):** the rollover backup
  commands in `DEPLOY.md` used a `/root/rquant-profile-rollover-*/` glob that `lighthouse`
  cannot expand, and the very next step deletes `current.json` — fixed to the `${STAMP}`
  form with a confirming `ls` before the deletion.
- **S-1 (code):** on route B a role that needs a capability but received no credential
  directory still degraded silently, because the `expected_generation is None` branch sat
  ahead of the fail-closed diagnosis — the refusal now covers that crossing too, with its
  own cases.
- **S-2 / S-3 / S-4:** the report's `ruff format` claim corrected, the manifest consequence
  corrected from "would not run" to "would fail", and the CHANGELOG written.
- Notes N-1…N-6 are recorded in the review; N-1 (CI wiring) is what this integration
  implements, and N-5 (the two role-policy digests in `DEPLOY.md` cannot be recomputed from
  what the document states) is still open and worth a follow-up line for the owner.

`ruff check` passes on all 18 changed Python files. `ruff format --check` reports four
files, all four of which are already unformatted on `a90f927`; the one file this branch had
regressed is clean again.

## Security conclusion

**Allowing `CREDENTIALS_DIRECTORY` through the wrapper grants no new read capability.** The
value systemd sets is always the unit's own `/run/credentials/<unit>`, `build_child_environment`
copies it verbatim and never composes a path or walks that tree, and exactly one place in
the repository reads the variable. Reading is guarded by absolute-path, `O_NOFOLLOW`,
owner, `nlink`, mode and re-stat checks, and a credential belonging to another role is
refused on four fields (`service_id`, `service_kind`, `instance_name`,
`bundle_generation`) — the six-way cross-delivery cases prove it. One pre-existing fact
stated plainly: all runtime units run as `lighthouse`, so per-unit 0700 credential
directories separate users, not sibling roles of the same uid — and that path was already
open to a compromised `lighthouse` process before this change. Naming the variable in the
allowlist only tells a process where its own credential is.

**Validating against the bundle generation does not abandon the authority-chain binding.**
`schema_generation` comes from `resolve_legacy_schema_generation()` (#207), which requires
the manifest to sit under `<authority generation>/manifests/` and the root-owned
`legacy-binding.json` — whose sha256 is in the full manifest, whose own sha256 *is* the
authority generation id — to name this runtime root and the generation `current` points at.
`load_authority_service_manifest(..., expected_generation=...)` at the top of `run()` is
untouched. The credential is therefore still bound to the authority chain, transitively,
through a root-signed chain. Every other new branch is a tightening: a missing credential
directory, a directory without `capabilities.json`, and route B with a credential in hand
all now refuse where they previously degraded silently.

**The `profile_id` changes, and that has an install consequence — owner action required.**
`environment_allowlist` feeds the `profile_id` hash, so adding `CREDENTIALS_DIRECTORY`
necessarily produces a new `profile_id`, and #190 is unfixed: with a `current.json` already
in place the publication primitives validate each slot against the installed profile and
refuse a different one. **@roxorlt** — the next install window must follow the
"⚠️ 下一个装机窗口的强制前置" section of `DEPLOY.md` exactly: stop the started units, back up
both root documents under `${STAMP}` and confirm with `ls` before deleting anything, remove
`/var/lib/rquant/runtime-authority/current.json`, then stage and publish with the new code
so `previous is None` and the chain restarts at **sequence 1**. The criterion is still
`wrapper_preflight == 32` from a real publish, not a `--dry-run`. Rollback restores both
documents from the same stamped directory; the legacy bundle does not need reinstalling and
the sealed `.cred` files are unaffected, since `current.cred` is addressed by bundle
generation.

## R07

Baseline refrozen from PR #213's `695e952` (tree `40b61c96`) to PR #219's `a90f927` (tree
`14843e03`), all four sites moved together, policy regenerated with
`scripts/r07_policy_regenerate.py --repo . --staged` to a byte fixed point. The allowlist is
exactly this branch's merge face against `a90f927`: **29 entries** after the conftest fix
added one path, set identical to `git diff --raw --no-renames --cached a90f927`,
`policy_digest`
`6c1f4168a9d71259160f5921fb85427ff5a1e4ed45b752f3237cc663ac4415df`. `validate` resolves the
merge base to the frozen constant and refuses the stale one. Both R07 gate suites pass on
3.11 and 3.12 (295 each).

## CI: what the two runs found

Run 1 (`34075644436`, head `88bfdb7`) was red on six shards. Seven cases failed; six of them
were one bug that macOS cannot see, and that one is fixed here. Run 2 (`34079743041`, head
`c7b6a2f`) has none of the six left.

**In scope, fixed.** Six cases across three files
(`test_tp9_role_child_runtime.py` ×2, `test_runtime_service_main.py` ×3, the notifier case
in `test_route_a_credstore_roles_e2e.py`) all ended in

    ValueError: runtime capability credential was not delivered to <kind>: systemd loaded
    no capabilities.json for unit hosted-compute-agent.service

`_undelivered_credential_reason` decides whether a missing credential is worth accusing a
unit over by reading `/proc/self/cgroup` and taking the leaf ending in `.service`, and its
`None` branch is documented as "a bare diagnostic run, or the suite". On Darwin that is
true for free — there is no `/proc`. A GitHub Linux runner puts the whole job inside
`hosted-compute-agent.service`, so every role a test starts without a credential is accused
of a unit that has nothing to do with rQuant. The suite's premise held by accident of
platform.

The fix is test-level, because the premise is: an autouse fixture in `tests/conftest.py`
points the probe at a path that does not exist, beside the fixture that already keeps the
suite off the real push channels. The cases that are about the probe set the same attribute
for themselves and still win. Reproduced before fixing rather than inferred: with
`_SYSTEMD_CGROUP_PATH` aimed at a file containing
`0::/system.slice/hosted-compute-agent.service`, the same six cases fail on macOS with the
same six messages, and pass with the fixture in place while
`test_credstore_capability_delivery.py` stays green.

The production probe is unchanged. On a host it still refuses where the role could not have
worked anyway; only the unit it names can be wrong when the process is not a runtime unit.
**That is worth a follow-up for the package author** — it is the inverse of review note N-2,
which recorded the probe failing to recognise a unit that is one.

**Out of scope, recorded only.** `test_source_broker_v2_service.py::
test_claim_signing_uses_remaining_single_request_deadline` failed once on shard (3.11, 3)
with `SourceBrokerV2TransportDeadlineError: server deadline expired before claim response
signing`. That file is untouched by this branch, the failure is a wall-clock budget
overrun, and it belongs to the known family already tracked as #160 / #168 / #195. It
passes locally. No fix attempted here.

R07 was regenerated after the fix so the allowlist covers `tests/conftest.py` (29 entries),
and that regeneration is the branch's last commit.

**Run 2 result.** Eighteen of twenty-one jobs green, including both new
`Linux Route A credstore roles` legs, both `Linux Route A legacy binding` legs, both R07
gates, the Darwin lane and core-preflight. All six of run 1's in-scope failures are gone.
Three jobs are not green and none of them is a package E defect:

| Job | What happened |
|---|---|
| Full suite shard (3.11, 3) | One failure, `test_production_deploy.py::test_subprocess_runner_timeout_terminates_descendant_process_group`, ending in `TimeoutError: process inventory timed out` from `contained_subprocess`. That file and that module are untouched by this branch, it is a fixed execution deadline losing to a loaded runner, and it is the same mechanism as **#161**. Passes locally. |
| Full suite shard (3.12, 0) | **3589 passed, 51 skipped, 0 failed** in 1:13:46 — every test green. The job's own `timeout-minutes: 75` then fired during the steps after pytest, so GitHub marks it cancelled. |
| Full suite contract (3.11) | Downstream only: `ContractError: shard 3 reported ... test_subprocess_runner_timeout_terminates_descendant_process_group as failed`. The 3.12 contract passed. |

Both of those are runner-time symptoms rather than code, and run 2 had a reason to be slow:
it started while run 1's last three shards were still executing, so eleven full-suite shard
jobs shared the runner pool. Run 1's shards took 22–46 minutes; run 2's slowest needed 74.
A run started on its own has room the 75-minute cap did not give this one.

Per the integration brief this branch gets one re-run for an in-scope red, which run 2 was,
so no third run was started. **Whoever merges should re-run these three jobs on their own
first** — nothing here needs a code change.

## Local verification

| Scope | Environment | Result |
|---|---|---|
| Package E targeted units (9 files) | macOS 3.11.15 | 185 passed |
| Package E targeted units (9 files) | macOS 3.12.13 | 185 passed |
| Credstore + legacy binding end to end | macOS 3.11.15 | 45 passed, 2 deselected |
| R07 gate and shard suites (6 files) | macOS 3.11.15 / 3.12.13 | 295 passed each |
| `full_suite_shards.py check`, four shards | macOS 3.11.15 | rc 0 each |
| New CI job, replayed verbatim | `python:3.11-slim` / `python:3.12-slim`, root | 1 passed each, contract green |

All of the above were re-run after the conftest fix; the numbers are the post-fix ones.

No version bump: `v0.33.0` is tagged after package F, per the integration brief.

**Merge with "Create a merge commit"** — R07 merge-provenance requires the candidate to
have exactly two parents.

Refs #207 #217 #218 #190

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01Moh45U775Rd9XxYhx649fg
