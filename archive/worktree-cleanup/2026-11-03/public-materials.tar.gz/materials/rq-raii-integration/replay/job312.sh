#!/bin/bash
# Every `run:` block of route-a-credential-shape-linux, in order, each in its own shell the way
# GitHub runs steps. Removed: checkout / setup-python / uv (the image is the interpreter) and
# `sudo` (the container is already root).
set -euo pipefail
export RUNNER_TEMP=/work/runner-temp
export GITHUB_ENV=/work/github-env
export GITHUB_WORKSPACE=/repo
mkdir -p "$RUNNER_TEMP"; : > "$GITHUB_ENV"

echo "### step: Create the private test root"
(
  set -euo pipefail
  umask 077
  exact_root="${RUNNER_TEMP}/rquant-cred-shape-py3.12"
  mkdir -p "${exact_root}/data" "${exact_root}/parquet" "${exact_root}/logs"
  mkdir -p "${exact_root}/pytest" "${exact_root}/test-results"
  chmod 700 "${exact_root}" "${exact_root}/data" "${exact_root}/parquet"
  chmod 700 "${exact_root}/logs" "${exact_root}/pytest" "${exact_root}/test-results"
  {
    printf 'RQUANT_CRED_SHAPE_ROOT=%s\n' "${exact_root}"
    printf 'DATA_DIR=%s/data\n' "${exact_root}"
    printf 'DUCKDB_PATH=%s/data/main.duckdb\n' "${exact_root}"
    printf 'DUCKDB_READONLY_PATH=%s/data/readonly.duckdb\n' "${exact_root}"
    printf 'PARQUET_DIR=%s/parquet\n' "${exact_root}"
    printf 'LOG_DIR=%s/logs\n' "${exact_root}"
  } >> "${GITHUB_ENV}"
)
set -a; . "${GITHUB_ENV}"; set +a
cat "${GITHUB_ENV}"

echo "### step: Install the ACL tools if the image lost them"
(
  set -euo pipefail
  if ! command -v setfacl >/dev/null 2>&1; then echo "would apt-get install acl"; fi
  command -v setfacl
)

echo "### step: Record the kernel and whether its tmpfs holds POSIX ACLs"
(
  set -euo pipefail
  uname -r
  probe="${RUNNER_TEMP}/acl-probe"
  mkdir -p "${probe}"
  mount -t tmpfs -o mode=0700 tmpfs "${probe}"
  touch "${probe}/probe"
  if setfacl -m u:1000:r "${probe}/probe"; then
    echo "tmpfs holds POSIX ACLs on this runner: the ACL cases run the production shape"
  else
    echo "tmpfs refuses POSIX ACLs on this runner: the ACL cases fall back to an injected table"
  fi
  umount "${probe}"
  rmdir "${probe}"
)

echo "### step: Run the systemd credential delivery gate as root"
(
  set -euo pipefail
  umask 022
  junit="${RQUANT_CRED_SHAPE_ROOT}/test-results/route-a-credential-shape.xml"
  python -m pytest \
    -o addopts='' --strict-markers -m linux_exact -rA -p no:cacheprovider \
    --basetemp="${RQUANT_CRED_SHAPE_ROOT}/pytest" \
    --junitxml="${junit}" \
    tests/integration/test_systemd_credential_delivery_linux.py
)

echo "### step: Verify the gate ran all fifteen cases and skipped nothing"
(
  set -euo pipefail
  python tests/support/assert_junit_contract.py \
    --path "${RQUANT_CRED_SHAPE_ROOT}/test-results/route-a-credential-shape.xml" \
    --suites 1 --tests 15 --failures 0 --errors 0 --skipped 0 --cases 15
  grep -q 'test_the_delivery_acl_is_what_admits_the_reader' \
    "${RQUANT_CRED_SHAPE_ROOT}/test-results/route-a-credential-shape.xml"
)
echo "### contract green"
