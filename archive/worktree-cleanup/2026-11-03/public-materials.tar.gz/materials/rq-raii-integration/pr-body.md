Fixes #230
Refs #215 #227

## 改了什么

#215 有三处断点，这是第三处。前两处修完之后凭证终于送到了角色手上，但**读者的判据描述的不是
systemd 真正投递的东西**：2026-09-08 02:04 第三窗口实测，`LoadCredentialEncrypted=` 交给
`User=lighthouse` 的是 `/run/credentials/<unit>/` 上一块 `ro,nosuid,nodev,noexec` 的内存挂载，
目录 `root:root 0550`，`capabilities.json` 是 `root:root 0440` 外加一条放行 lighthouse 的
POSIX ACL；而 `runtime_capabilities._read_private_credential` 要求 `st_uid == os.geteuid()`
且 `mode & 0o077 == 0`，属主与 group 位两条都不满足，五个 credstore unit 全部起不来。包 E 的
e2e 用「当前用户属主 + 0400」造夹具——那是照着读者写的，不是照着 systemd 写的，所以这条一路
绿到生产。

改法不是放宽成「任何可读文件都接受」，而是把判据换成 systemd 自己的契约，每条都指得到出处
（systemd 255 的 `src/core/exec-credential.c` 与 `src/shared/mount-util.c`）：目录必须是
`/run/credentials/<本 unit>.service`（读得出 cgroup 时还要与本进程所属 unit 一致）、属
`root:root` 或本进程 `uid:gid`、mode ∈ {0500, 0550, 0700}，所在挂载是 tmpfs/ramfs、带
`nosuid,nodev,noexec`、**并且只读**（读 `/proc/self/mountinfo` 核对，再用目录自己的 `st_dev`
反查选中的确实是这一条）；文件 `O_NOFOLLOW` 打开、正规文件、nlink 1、属主 ∈ {0, 本进程 euid}、
mode ∈ {0400, 0440} 且 `mode & 0o007 == 0`、带 group 读位时必须 `root:root`、读后 fstat 互校、
1 MiB 上限。措辞也一并改了：`User=` 配错时文件与目录的 ACL 一起没有、连 `lstat` 都被拒，这时
点名**目录**的实测属主与 mode，而不是退回「unavailable or unsafe」这种一个值都不点名的串；
`_undelivered_credential_reason` 把「已装载但读不动」误报成「从来没装载」的同源坑一并修了。

测试：macOS 侧 `tests/unit/test_systemd_credential_delivery_shape.py` 28 例（判据表正反两面），
Linux 侧 `tests/integration/test_systemd_credential_delivery_linux.py` 15 例——真 tmpfs 挂载、
真只读重挂、root 造投递、真 POSIX ACL、真 EACCES，再用一个真正的非 root 子进程读回。**一处
skip 都没有**，连「这台机器的 tmpfs 能不能放 ACL」都是运行期探测出来的。那 15 例全带
`linux_exact`、不进任何分片，所以本 PR 新增 CI job `route-a-credential-shape-linux`：裸
`ubuntu-24.04` runner（不是容器，因为要一块真能放 ACL 的 tmpfs）、`sudo -E` 取 root、JUnit
契约钉 `--suites 1 --tests 15 --failures 0 --errors 0 --skipped 0 --cases 15`。

CI 接线走了三轮真 runner 才定形，最后的结论是**这个 gate 必须跑在带 root 的容器里**，而不是
审查建议的裸 runner。审查的理由（只有真内核的 tmpfs 才放得下投递 ACL）成立，但那是**内核**的
属性，不是容器的：`CONFIG_TMPFS_POSIX_ACL` 由内核决定，容器 job 用的就是 runner 的宿主内核。
裸 runner 上实测内核 `6.17.0-1022-azure`、tmpfs 上 `setfacl` 成功，所以两种跑法里 ACL 都是真的；
真正决定选哪种的是另外两条，都只有真 runner 能暴露：
① `test_a_credential_on_an_ordinary_filesystem_is_refused` 故意把目录**不放**在内存挂载上，
看读者按「不是内存文件系统」拒掉它；而 systemd 主机上 `/run` 本身就是 tmpfs，裸 runner 上这条
就落到了内存挂载上、改被下一条判据（缺 `noexec`）拒掉——照样拒了，但问的问题变了。
② 裸 runner 的 job 本身跑在 `hosted-compute-agent.service` 里，读者取 `/proc/self/cgroup` 的
`.service` 叶子执行「只能读自己 unit 的凭证」，于是 15 例里 14 例被判成「属于别的 unit」。
容器里 `/proc/self/cgroup` 是 `0::/`、根是 overlay，正是这 15 例被写出来时的环境。
容器加 `--cap-add=SYS_ADMIN`（挂载与只读重挂）和 `--security-opt apparmor=unconfined`
（AppArmor 的 `docker-default` 无条件拒 `mount`，这条本地 Docker Desktop 复现不出来，那台宿主
根本没跑 AppArmor）。集成侧另有三件：full-suite 分片重生成（14070 → 14098，+28 全部来自那个 unit 文件，`extra=0`）、
DEPLOY.md 前置补第 32 条（第三处断点 + 判据摘要 + 裁决 19），以及 R07 基线重冻结到 `a0bbb4c`
并重生成 policy（23 条，`policy_digest a9c75623…`）。

## 审查裁定

两轮独立审查，最终裁定**通过，可合入**。审查记录在 Mac 本地的
`/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-i-cc/.superpowers/sdd/2026-09-08-systemd-credential-shape/pkgI-review.md`
（第一轮 must-fix 2 条、should-fix 7 条、note 4 条；第二轮 delta 复核在同文件「第二轮复审」一节），
实现报告在同目录的 `pkgI-report.md`。

第一轮两条 must-fix 都已修：MF-1「0440 必须 root:root」原先无测试覆盖、变异双侧存活，现在
macOS/Linux 各有正反用例钉住；MF-2「最可能的生产失败态（`User=` 配错、目录进不去）措辞退化成
通用串」，现在点名目录的实测属主与 mode。七条 should-fix 里最要紧的 SF-1（目录属主放宽到完整
属主 fallback）与 SF-2（`ro` 升硬要求）就是**裁决 19**；SF-3 把三处 `pytest.skip` 全改成
`pytest.fail`，SF-4 把「tmpfs 能不能放 ACL」从假设改成运行期探测。审查独立跑了 14 条变异，
全部被杀；两版本定向集各 366 passed；Linux 门禁 15 例全过。

## 安全结论

放弃「属主 == euid」这条判据**在宿主 mount namespace 内是加严，不是放宽**：

- 「只有 systemd 能把这个文件放在这里」原先靠属主承担，现在靠**路径 + 挂载**承担。
  `/run/credentials` 是 root 属主 0755，非特权进程在里面建不出 per-unit 目录（实测
  `mkdir → Permission denied`）；tmpfs/ramfs 在宿主 namespace 里非特权进程也挂不出来（实测
  `mount → must be superuser`）；再加 `nosuid,nodev,noexec` 与「目录 `st_dev` 必须与
  mountinfo 里选中那条对得上」的设备号反查（把设备号改成 `0:999` 即拒）。
- **ramfs 完整属主 fallback 那一支**（目录与文件都属服务用户）是唯一「不属 root」的被接受形状，
  它的安全前提是 systemd 自己写的：属主 fallback「only safe if we can then re-mount the whole
  thing read-only, so that the user can no longer chmod() the file to gain write access」。
  实测过这条 `ro` 的效力：以该 uid 去 `chmod` 目录得 `Read-only file system`，删文件、建硬链接、
  写新文件全部 `Permission denied`——属主身份在只读挂载上换不出任何写权限。所以这一支靠
  **`ro` + tmpfs/ramfs + `nosuid,nodev,noexec` + `/run/credentials` 是 root 0755 的路径**
  四件事共同承担，攻击者要利用它，得先让 root 替他在 `/run/credentials/` 下建一个 per-unit 目录
  并挂一块只读内存文件系统——那正是 systemd 在干自己的活。被接受的属主恰好两个（`root:root`
  与本进程 `euid:egid`），第三方属主仍然被拒（Linux 门禁与 macOS 侧各有一条正面用例）。
- **`ro` 是硬要求**，不只对 fallback 那一支：systemd 在把工作区移到最终位置前恒重挂只读，
  所以每一种形状都要求只读，可写挂载一律拒（正反两条用例：完美 ACL 形状挂 rw 也拒）。
- **unprivileged user namespace 伪造**：性质与影响都没变——只在攻击者自己的 mount namespace 里
  可见，仍然需要先控制读者的父进程或环境，而旧判据「属主 == euid」在同样前提下**更容易满足**。
  净损失为零。
- **同 uid 角色之间的隔离靠两层叠加**：形状层是「目录必须是本 unit 自己的」（`/proc/self/cgroup`
  读得出才施加），第二层是凭证内容里 `service_id` / `instance_name` / `bundle_generation` 三核。

**裁决 19（D4 目录属主放宽 + `ro` 升硬要求）属 TCB 相邻变更，向 @roxorlt 点名。** 已写进
DEPLOY.md 前置第 32 条。本 PR **不改 `PRODUCTION_ROLE_POLICY`**，角色策略摘要 `681151cb…`
与由它推出的换代要求不受影响，没有新增换代理由；版本号不 bump。

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01Moh45U775Rd9XxYhx649fg
