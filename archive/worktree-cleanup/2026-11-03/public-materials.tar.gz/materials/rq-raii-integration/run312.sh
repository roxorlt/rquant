cd /Users/roxor/brain/30-projects/rQuant/.worktrees/ra-i-cc
exec ./.venv312/bin/python -m pytest -q --basetemp=/Users/roxor/rq-raii-integration/tgt312 \
  tests/unit/test_systemd_credential_delivery_shape.py tests/unit/test_runtime_capabilities.py \
  tests/unit/test_credstore_capability_delivery.py tests/unit/test_credstore_role_child_environment.py \
  tests/unit/test_runtime_credential_keys.py tests/unit/test_runtime_credential_sealer_client.py \
  tests/unit/test_runtime_credential_sealer_helper.py tests/unit/test_provision_runtime_recovery_credentials.py \
  tests/unit/test_runtime_systemd_services.py tests/integration/test_source_broker_peer_credentials.py \
  tests/integration/test_production_artifact_terminal_lifecycle.py tests/integration/test_route_a_credstore_roles_e2e.py
