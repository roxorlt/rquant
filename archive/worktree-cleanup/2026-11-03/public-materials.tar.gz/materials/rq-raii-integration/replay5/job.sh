#!/bin/bash
# Every `run:` block of route-a-credential-shape-linux, in order, each in its own shell the way
# GitHub runs steps. The checkout is replaced by a copy of the worktree into a container-local
# workspace; everything else is verbatim.
set -euo pipefail
export GITHUB_ENV=/work/github-env
: > "$GITHUB_ENV"
PYV="${PYV:-3.11}"

echo "### step: Install the mount and ACL tools and the checkout prerequisites"
( set -euo pipefail
  apt-get update -qq
  apt-get install -y -qq --no-install-recommends acl mount util-linux git ca-certificates ) > /dev/null

echo "### step: checkout (replaced by a copy)"
export GITHUB_WORKSPACE=/__w/rquant/rquant
mkdir -p "$GITHUB_WORKSPACE"
tar -C /repo --exclude=./.venv --exclude=./.venv312 --exclude=./.git --exclude=./.superpowers -cf - . | tar -C "$GITHUB_WORKSPACE" -xf -
rm -f "$GITHUB_WORKSPACE/.env"
cd "$GITHUB_WORKSPACE"

echo "### step: Create the private test root"
( set -euo pipefail
  umask 077
  exact_root="/rquant-cred-shape-py${PYV}"
  mkdir -p "${exact_root}/data" "${exact_root}/parquet" "${exact_root}/logs"
  mkdir -p "${exact_root}/pytest" "${exact_root}/test-results"
  chmod 700 "${exact_root}" "${exact_root}/data" "${exact_root}/parquet"
  chmod 700 "${exact_root}/logs" "${exact_root}/pytest" "${exact_root}/test-results"
  {
    printf 'RQUANT_CRED_SHAPE_ROOT=%s\n' "${exact_root}"
    printf 'DATA_DIR=%s/data\n' "${exact_root}"
    printf 'DUCKDB_PATH=%s/data/main.duckdb\n' "${exact_root}"
    printf 'DUCKDB_READONLY_PATH=%s/data/readonly.duckdb\n' "${exact_root}"
    printf 'PARQUET_DIR=%s/parquet\n' "${exact_root}"
    printf 'LOG_DIR=%s/logs\n' "${exact_root}"
  } >> "${GITHUB_ENV}" )
set -a; . "${GITHUB_ENV}"; set +a

echo "### step: Install uv"
python -m pip install --root-user-action=ignore -q uv==0.10.11

echo "### step: Install locked dependencies"
uv sync --frozen 2>&1 | tail -2

echo "### step: Record the root, the cgroup and whether this tmpfs holds POSIX ACLs"
( set -euo pipefail
  test "$(id -u)" -eq 0
  uname -r
  cat /proc/self/cgroup
  probe=/rquant-acl-probe
  mkdir -p "${probe}"
  mount -t tmpfs -o mode=0700 tmpfs "${probe}"
  touch "${probe}/probe"
  if setfacl -m u:1000:r "${probe}/probe"; then
    echo "tmpfs holds POSIX ACLs here: the ACL case runs the production shape"
  else
    echo "tmpfs refuses POSIX ACLs here: the ACL case falls back to an injected table"
  fi
  umount "${probe}"
  rmdir "${probe}" )

echo "### step: Run the systemd credential delivery gate"
( set -euo pipefail
  umask 022
  junit="${RQUANT_CRED_SHAPE_ROOT}/test-results/route-a-credential-shape.xml"
  uv run python -m pytest -o addopts='' --strict-markers -m linux_exact -rA \
    -p no:cacheprovider \
    --basetemp="${RQUANT_CRED_SHAPE_ROOT}/pytest" \
    --junitxml="${junit}" \
    tests/integration/test_systemd_credential_delivery_linux.py 2>&1 | tail -4 )

echo "### step: Verify the gate ran all fifteen cases and skipped nothing"
( set -euo pipefail
  uv run python tests/support/assert_junit_contract.py \
    --path "${RQUANT_CRED_SHAPE_ROOT}/test-results/route-a-credential-shape.xml" \
    --suites 1 --tests 15 --failures 0 --errors 0 --skipped 0 --cases 15
  grep -q 'test_the_delivery_acl_is_what_admits_the_reader' \
    "${RQUANT_CRED_SHAPE_ROOT}/test-results/route-a-credential-shape.xml" )

echo "### step: Collect the JUnit evidence into the workspace"
( set -euo pipefail
  mkdir -p "${GITHUB_WORKSPACE}/cred-shape-evidence"
  cp -a "${RQUANT_CRED_SHAPE_ROOT}/test-results/." "${GITHUB_WORKSPACE}/cred-shape-evidence/"
  ls "${GITHUB_WORKSPACE}/cred-shape-evidence/" )
echo "### job green"
