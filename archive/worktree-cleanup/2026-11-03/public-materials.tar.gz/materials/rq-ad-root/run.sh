#!/bin/bash
# usage: run.sh <lane> <pytest args...>
set -u
lane="$1"; shift
set -a; . /Users/roxor/rq-ad-root/env.txt; set +a
export PYTHONDONTWRITEBYTECODE=1
bt="$RQUANT_CI_PYTEST_BASETEMP-$lane"
cd /Users/roxor/brain/30-projects/rQuant/.worktrees/ra-ad-cc
start=$(date +%s)
.venv/bin/python -m pytest -q -p no:randomly -p no:cacheprovider --basetemp "$bt" "$@" > /Users/roxor/rq-ad-root/lane-$lane.log 2>&1
rc=$?
end=$(date +%s)
echo "RC=$rc ELAPSED=$((end-start))s" >> /Users/roxor/rq-ad-root/lane-$lane.log
chmod -R u+rwx "$bt" 2>/dev/null; rm -rf "$bt"
exit $rc
