Closes #289. Package AD: a hotfix for the opening-auction chain on top of v0.33.18 (#288).

## What happened on 2026-09-23 and why this change

- **The data was there.** A read-only probe with the production main token showed `stk_auction(20260923)` returning 0 rows at 09:26:54 and **6,077 rows at 09:27:14**, so first availability that day was T = 09:27:14. The v0.33.18 capture (window 09:35-10:05, six attempts) got the full 6,077-row feed on its first attempt at 09:35:00, which confirms the #277 `pre_close` fix.
- **The whole batch was rejected anyway.** **407 of those rows had `price = NaN`** (and `vol = 0`, `amount = 0`, `pre_close` present). These are stocks with no auction match that day, either suspended or with no quotes. The gateway treated any non-finite required value as a malformed feed and rejected the whole table as `validation_failed:required numeric values must be finite`. It published a 0-row DEGRADED batch, so `candidate.auction_gap` reported `auction_gap_input_unavailable` for the rest of the day, and watchlist-quote / market-minute degraded with it. Acceptance criterion 3a failed for that day.
- **After the fix, coverage passes on that same feed.** Coverage is the kept rows that are in the auction universe divided by the universe. Measured on the host with the 09-23 feed and that day's universe (`authorities/auction-universe/current.json`), it is **5,464 / 5,554 = 98.4 %**, which is at or above `min_coverage_ratio` = 0.95. So the 09-23 feed now publishes as PUBLISHED, and the threshold stays at 0.95.

## Behavior

- A row whose required numeric columns (`price` / `vol` / `amount` / `pre_close`) contain NaN or ±inf is **dropped and counted**. The rest of the table is normalized as before. Whether the batch is PUBLISHED or DEGRADED is still decided only by coverage (`min_coverage_ratio`, default 0.95) and the required-code rule, and neither rule is relaxed. A dropped row inside the universe still costs coverage; a unit test pins that.
- These shapes are **still rejected as a whole batch**, as package Y left them: missing columns, bad or duplicate `ts_code`, bool values, wrong `trade_date`, non-numeric values, `price`/`pre_close` ≤ 0, `vol`/`amount` < 0, ±inf or negatives in the optional columns. NaN in the optional columns (`turnover_rate` / `volume_ratio`) was already allowed and still is.
- **The count goes on the heartbeat as `auction_match:rows_dropped_non_finite:<n>`**, taken from `AuctionMatchCapture.rows_dropped_non_finite` by the runtime step. It is **not in the batch envelope**, because `BatchEnvelope` forbids `degraded_reasons` on a non-degraded batch. Writing the count there would make the batch DEGRADED, and `candidate.auction_gap` accepts only PUBLISHED batches, so the fix would cancel itself.
  - Side effect (see DEPLOY.md section 2, item 5): the idle rounds after the window carry the last result's reasons forward. So from the first capture that drops a row until the trade-date rollover, the auction-match heartbeat status is `degraded`, and runtime-health gains one `degraded:<auction-match instance>` entry. This is display only; no deployer, watchdog or assembly step reads it. A follow-up issue will move the count to an informational heartbeat field.
  - The heartbeat is written to disk, but the count is not stored in the batch. After a restart inside the window, the idempotent re-check reads the published batch and the line disappears. The batch and everything downstream are unaffected.

## Window change

T = 09:27:14 replaces the 09-22 bracket (09:26:08 empty, 09:51:11 non-empty), so the window is narrowed:

| Constant | v0.33.18 | This PR |
|---|---|---|
| `AUCTION_MATCH_DEFAULT_CAPTURE_START` / `_END` | 09:35 / 10:05 | **09:29 / 09:44** |
| `AUCTION_MATCH_DEFAULT_MAX_ATTEMPTS` | 6 | **3** (`900 // 3 = 300` s: attempts at 09:29 / 09:34 / 09:39, all inside `[09:29, 09:44)`) |
| `AUCTION_GAP_DEFAULT_INPUT_START` / `_END` | 09:35 / 10:10 | **09:29 / 09:49** |

The start is 106 s after T, which leaves room for a day when data arrives a little later. The 15-minute window covers a day up to ten minutes later than T. The settings default, the production profile's `max_attempts`, route B's bootstrap derivation and the four-constant consistency gate all read these constants; there is no second copy of the literal. On a day like 09-23, the 09:29 attempt should already be PUBLISHED, so the market-minute / watchlist-quote degraded stretch after 09:30 is close to zero.

## Integration

- Consumer tests (every test file that mentions a changed module, plus the named sets): all passed. Counts are in the integration report.
- Full-suite manifests regenerated: 14758 -> 14763 cases, skips unchanged at 55. All five shards pass `check`, the Darwin lane is byte-identical, and the frozen source-broker collection is unchanged. With the new LPT placement, the slowest shard's estimated test time (from the v0.33.18 JUnit times) goes down, from 92.7 to 79.5 min on 3.12.
- Review follow-ups: DEPLOY now says the all-day `degraded` status is expected (SF-2), and a stale 09:26-09:30 comment in `readside_replica_gate.py` is corrected (SF-3, comment only).
- The last commit refreezes R07 to `911f24125e05bdaea652744ccac5edd43afb6d75` (v0.33.18).

After merge: annotated tag `v0.33.19` on the merge commit. The earliest this can take effect is the next open after the deploy; see DEPLOY.md section 0.1.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01Moh45U775Rd9XxYhx649fg
