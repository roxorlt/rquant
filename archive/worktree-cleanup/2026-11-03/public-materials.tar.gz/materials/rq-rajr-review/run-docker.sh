#!/bin/sh
set -e
PYTAG="$1"
TAGID="$2"
docker volume rm -f "rajr-$TAGID" >/dev/null 2>&1 || true
docker volume create "rajr-$TAGID" >/dev/null
docker run --rm --name "rajr-$TAGID" \
  -v /Users/roxor/rq-rajr-review/src-copy:/src:ro \
  -v "rajr-$TAGID":/home/runner \
  -e PYTAG="$PYTAG" \
  python:${PYTAG}-slim /bin/sh -c '
set -e
apt-get update -qq >/dev/null 2>&1
apt-get install -y -qq curl ca-certificates git >/dev/null 2>&1
useradd -u 1000 runner || true
mkdir -p /home/runner && chown runner:runner /home/runner && chmod 700 /home/runner
su runner -s /bin/sh -c "
set -e
umask 077
export HOME=/home/runner
curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1
export PATH=\$HOME/.local/bin:\$PATH
mkdir -p \$HOME/work && cp -a /src/. \$HOME/work/
cd \$HOME/work
git init -q . && git config user.email r@e.x && git config user.name r && git add -A && git commit -qm baseline
uv sync --frozen --python \$PYTAG >/dev/null 2>&1
export RQUANT_DISABLE_DOTENV=1 TUSHARE_TOKEN_MAIN=00000000000000000000000000000000 NOTIFY_ENABLED=false
root=\$HOME/rqci
mkdir -p \$root/tmp \$root/data \$root/parquet \$root/logs
chmod 700 \$root \$root/tmp \$root/data \$root/parquet \$root/logs
export TMPDIR=\$root/tmp TMP=\$root/tmp TEMP=\$root/tmp
export DATA_DIR=\$root/data DUCKDB_PATH=\$root/data/test.duckdb DUCKDB_READONLY_PATH=\$root/data/test_ro.duckdb PARQUET_DIR=\$root/parquet LOG_DIR=\$root/logs
echo UID=\$(id -u)
uv run python -V
uv run pytest -q \$(cat fileset.txt | tr \"\\n\" \" \")
"
'
