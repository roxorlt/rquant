#!/bin/sh
set -e
docker run --rm --name rajr-collect \
  -v /Users/roxor/rq-rajr-review/src-copy:/src:ro \
  -v rajr-collect:/home/runner \
  python:3.11-slim /bin/sh -c '
set -e
apt-get update -qq >/dev/null 2>&1
apt-get install -y -qq curl ca-certificates git >/dev/null 2>&1
useradd -u 1000 runner || true
mkdir -p /home/runner && chown runner:runner /home/runner && chmod 700 /home/runner
su runner -s /bin/sh -c "
set -e
umask 077
export HOME=/home/runner
curl -LsSf https://astral.sh/uv/install.sh | sh >/dev/null 2>&1
export PATH=\$HOME/.local/bin:\$PATH
mkdir -p \$HOME/work && cp -a /src/. \$HOME/work/
cd \$HOME/work
git init -q . && git config user.email r@e.x && git config user.name r && git add -A && git commit -qm baseline
uv sync --frozen --python 3.11 >/dev/null 2>&1
export RQUANT_DISABLE_DOTENV=1 TUSHARE_TOKEN_MAIN=00000000000000000000000000000000 NOTIFY_ENABLED=false
root=\$HOME/rqci; mkdir -p \$root/tmp \$root/data \$root/parquet \$root/logs
chmod 700 \$root \$root/tmp \$root/data \$root/parquet \$root/logs
export TMPDIR=\$root/tmp TMP=\$root/tmp TEMP=\$root/tmp
export DATA_DIR=\$root/data DUCKDB_PATH=\$root/data/t.duckdb DUCKDB_READONLY_PATH=\$root/data/tro.duckdb PARQUET_DIR=\$root/parquet LOG_DIR=\$root/logs
uv run pytest -q --collect-only 2>&1 | tail -2
"
'
