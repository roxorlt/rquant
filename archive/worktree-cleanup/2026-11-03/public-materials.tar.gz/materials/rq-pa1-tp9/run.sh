#!/bin/zsh
# usage: run.sh [--py312] <pytest args...>
cd /Users/roxor/brain/30-projects/rQuant/.worktrees/pra-tp9-cc || exit 1
source .superpowers/sdd/2026-09-03-pra-tp9-cc/env-recipe.sh /Users/roxor/rq-pa1-tp9
PY=.venv/bin/python
if [[ "$1" == "--py312" ]]; then PY=.venv312/bin/python; shift; fi
exec "$PY" -m pytest "$@"
