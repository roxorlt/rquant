Closes #293. Package AE: a hotfix for the reference-slow source on top of v0.33.19 (#291). #295 stays open (see below).

## What happened in production and why this change

- **The reference-slow source has never published once since 09-14.** Every trading day at 09:20 `reference-slow.source.v1` failed, so `authorities/reference-slow` has no generation at all and `live/reference-slow/` holds only `quota.sqlite3` (09-14, 09-18, 09-21, 09-22 and 09-23 all look the same). `reference_slow_authority` is a hard source for serving, so serving refused every round and acceptance criterion 3b could not pass.
- **The first failure (09-23, 09:20:20):** the health authority recorded `ReferenceSlowSourceError: stock_basic source is missing columns: delist_date`. The journal shows `stock_st(20260923)` 204 rows and `stock_basic(list_status=L)` 5,568 rows, then nothing. `TushareAdapter.stock_basic` never put `delist_date` in `fields`, Tushare returns only the columns it is asked for, and the reference-slow validator treats `delist_date` as required.
- **The retries could not recover:** from 09:20:51 every round failed with `SourceQuotaConflictError: reference source attempt already exists: success` before sending any request. The attempt id is deterministic per day (#295, below).
- **The heartbeat was washed clean:** from 09:25 the out-of-window rounds return early with a clean result and `record_success` wrote the heartbeat back to running. Looking at the heartbeat, nothing said the source had never published.
- **A second defect behind the first:** replaying on the host with `delist_date` requested, L (5,568) and P (0 rows, columns present) pass, but the D list (339 rows) contains one historical row, `T600018.SH 上港集箱(退)` (delisted 2006-10-20, `market` empty). Its code fails the `ts_code` pattern, which rejected the whole D list and so the whole batch.

## Behavior

- **`stock_basic` asks for `delist_date`** (`STOCK_BASIC_COLUMNS`, every earlier column kept). An empty or `None` response now comes back as a zero-row frame with all requested columns, the same class of fix as #277 (a column-less empty frame reads as "missing columns").
- **In the D and P lists a row with a non-canonical code is skipped and counted.** Such a code cannot be in the prior session's daily universe, and the `stock_basic does not cover prior daily universe` coverage check still guards that. **The L list is still strict.** A list without the `delist_date` column, and a D row without a `delist_date` value, are still rejected as a whole batch.
- **The skip count goes to a journald WARNING** (`skipped <n> row(s) with a non-canonical ts_code: T600018.SH`). It is not in the batch envelope, because `BatchEnvelope` forbids `degraded_reasons` on a PUBLISHED batch. It is not on the heartbeat either: that row is in the D list every day, so the reference-slow source would show `degraded` every trading day (#290 tracks the same problem for auction-match).
- **A failed capture stays visible:** once a capture has failed on a trading day and no batch was captured that day, every later heartbeat carries `capture_failed:<class of the first failure>` until the trade-date rollover. Only the first class is kept, because the later rounds hit `SourceQuotaConflictError`, which is not the cause. The state is in-process and cleared by a role restart, as for auction-match.
- **`scripts/reference_slow_dry_run.py`:** a read-only real-data dry run of the same capture function production calls (real `TushareAdapter`, clock pinned to 09:20 of the target day). It builds the snapshot, the batch payload and the serving payload in memory and writes nothing (no spool, quota ledger, registry or authority).

## Host dry run tonight (coordinator, read-only)

With this branch's code and the production venv, `--trade-date 2026-09-23`, the run ended **`DRY RUN OK`**:

| step | result |
|---|---|
| `stock_basic` L / D / P | 5,568 / 338 facts + 1 skipped (`T600018.SH`) / 0 |
| `adj_factor(20260923)` | 5,568 rows |
| batch envelope (in memory) | `quality_status=published`, `row_count=5554` |
| `reference_slow_authority` serving payload | `status=fresh` |

What the dry run cannot prove: 09-23's data was long complete, so it says nothing about whether `adj_factor` for the day is already in Tushare at 09:20 tomorrow (Tushare documents 9:15-9:20). DEPLOY's new top entry lists what to look at in the 09:20 journal.

## Not fixed here: #295

One failed capture still makes the day unrecoverable. `logical_request_id` is derived from (source, trade date, `retry_ordinal`), and `retry_ordinal` is a manifest constant (0 in the production profile). With transport accounting, the first attempt's Tushare calls commit `success` as soon as HTTP returns, so after a validation failure every later round that day is refused with `attempt already exists: success`. That determinism is the guarantee against re-sending after a kill with an unknown outcome, so the fix is not small. This PR only makes the failure visible; #295 stays open.

## Integration

- Consumer tests (every test file that mentions a changed module, plus the named sets), on this worktree's Python 3.11.15 venv with CI-style dummy settings in the environment (no `.env`): 35 unit files 1680 passed; 5 integration files (`test_runtime_daily_rollout_e2e`, `test_runtime_shadow_completion_e2e`, `test_signal_family_root_verifier_isolation`, `test_route_a_trading_day_full_chain_e2e`, `test_route_a_all_roles_sandbox_e2e`) 92 passed; doc and manifest readers 827 passed / 3 skipped; after the refreeze, the R07 set 914 passed / 6 skipped, `test_signal_family_differential_gate.py` alone 65 passed, R07-adjacent integration and deploy files 544 passed / 4 skipped. All skips are existing platform skips.
- Full-suite manifests regenerated: 14763 -> 14781 cases (+18 / -0), skips unchanged at 55. All five shards pass `check`, the Darwin lane is byte-identical, and the frozen source-broker collection is unchanged (476). Estimated from the v0.33.19 JUnit times, the slowest shard is 87.1 min on 3.12, under the 120-minute limit.
- Docs: CHANGELOG records the host dry run; DEPLOY gains a pending-install entry with the 09:20 acceptance.
- The last commit refreezes R07 to `abb95f79a8683fd407fe01eff0664e8ce7dfdc71` (v0.33.19); `validate` with explicit endpoints is rc 0 and `merge_base == frozen`.

After merge: annotated tag `v0.33.20` on the merge commit, installed before tomorrow's 09:20 capture.

🤖 Generated with [Claude Code](https://claude.com/claude-code)

https://claude.ai/code/session_01Moh45U775Rd9XxYhx649fg
