set -euo pipefail
export HOME=/home/rq
# The authority publisher walks the whole parent chain of its deployment lock and refuses
# any ancestor with group/other write bits, so TMPDIR cannot live on /tmp (1777) or on a
# bind mount whose macOS ownership does not map. /home/rq is 0700, /home is 0755, / is 0755.
export TMPDIR=/home/rq/rqtmp TMP=/home/rq/rqtmp TEMP=/home/rq/rqtmp
mkdir -p "$TMPDIR" && chmod 700 "$TMPDIR"
export RQUANT_DISABLE_DOTENV=1
export TUSHARE_TOKEN_MAIN=00000000000000000000000000000000
export NOTIFY_ENABLED=false
export DATA_DIR=$TMPDIR/data DUCKDB_PATH=$TMPDIR/data/test.duckdb
export DUCKDB_READONLY_PATH=$TMPDIR/data/test_ro.duckdb
export PARQUET_DIR=$TMPDIR/parquet LOG_DIR=$TMPDIR/logs
mkdir -p "$DATA_DIR" "$PARQUET_DIR" "$LOG_DIR"
cd /rq/src
uv sync --frozen --python 3.11 >/dev/null 2>&1
.venv/bin/python -m pytest tests/integration/test_route_a_trading_day_full_chain_e2e.py \
  -q --basetemp="$TMPDIR/pt" "$@" 2>&1 | tail -12
