import json, subprocess, sys, time
from pathlib import Path

REPO = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-i-cc")
SRC = REPO / "src/rquant/runtime_capabilities.py"
ENV = {
    "TUSHARE_TOKEN_MAIN": "00000000000000000000000000000000placeholder",
    "DATA_DIR": "/Users/roxor/rq-rair-pkgI/data",
    "DUCKDB_PATH": "/Users/roxor/rq-rair-pkgI/data/rquant.duckdb",
    "PARQUET_DIR": "/Users/roxor/rq-rair-pkgI/data/parquet",
    "LOG_DIR": "/Users/roxor/rq-rair-pkgI/logs",
    "PATH": "/usr/bin:/bin:/usr/local/bin",
    "HOME": "/Users/roxor",
}
MAC_FILES = [
    "tests/unit/test_systemd_credential_delivery_shape.py",
    "tests/unit/test_runtime_capabilities.py",
    "tests/unit/test_credstore_capability_delivery.py",
]

NL = chr(10)
MUTATIONS = {
 "M1-owner-set-dropped": [("        if observed.st_uid not in (delivery_uid, runtime_uid):",
                          "        if False:  # MUTANT")],
 "M2-allow-0444": [("_CREDENTIAL_FILE_MODES = frozenset({0o400, 0o440})",
                    "_CREDENTIAL_FILE_MODES = frozenset({0o400, 0o440, 0o444})")],
 "M3-no-directory-criteria": [(NL.join(["    delivery_uid, delivery_gid = _SYSTEMD_DELIVERY_OWNER", "    unit = directory.name"]),
                    NL.join(["    return None  # MUTANT", "    delivery_uid, delivery_gid = _SYSTEMD_DELIVERY_OWNER", "    unit = directory.name"]))],
 "M4-no-mount-check": [(NL.join(["    entry = _containing_mount(directory)", "    if entry is None:"]),
                    NL.join(["    return None  # MUTANT", "    entry = _containing_mount(directory)", "    if entry is None:"]))],
 "M5-no-nlink": [("        if observed.st_nlink != 1:", "        if False:  # MUTANT")],
 "M6-no-unit-agreement": [("    if running is not None and running != unit:", "    if False:  # MUTANT")],
 "M7-no-ro-requirement": [('    if "ro" not in entry.options:', "    if False:  # MUTANT")],
 "M8-no-group-read-needs-root": [("        if mode & 0o040 and (observed.st_uid, observed.st_gid) != (delivery_uid, delivery_gid):",
                    "        if False:  # MUTANT")],
 "M9-no-device-crosscheck": [("    if entry.device != expected:", "    if False:  # MUTANT")],
 "M10-directory-owner-anyone": [("    if owner not in ((delivery_uid, delivery_gid), (os.geteuid(), os.getegid())):",
                    "    if False:  # MUTANT")],
 "M11-no-directory-mode": [("    if mode not in _CREDENTIAL_DIRECTORY_MODES:", "    if False:  # MUTANT")],
 "M12-no-mount-flags": [("    missing = tuple(name for name in _CREDENTIAL_MOUNT_OPTIONS if name not in entry.options)",
                    "    missing = ()  # MUTANT")],
 "M13-no-directory-wording-fallback": [("            parent = os.lstat(path.parent)", "            raise OSError  # MUTANT")],
 "M14-absent-swallows-eacces": [(NL.join(["    except FileNotFoundError:", "        return True", "    except OSError:", "        return False"]),
                    NL.join(["    except OSError:  # MUTANT", "        return True"]))],
}

def run(cmd, env=None, cwd=REPO):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True, cwd=str(cwd), env=env)

def counts(out):
    import re
    m = re.search(r"(\d+) failed", out); f = int(m.group(1)) if m else 0
    m = re.search(r"(\d+) error", out); e = int(m.group(1)) if m else 0
    return f + e

def mac():
    r = run(f".venv/bin/python -m pytest {' '.join(MAC_FILES)} -q -p no:cacheprovider "
            "--basetemp=/Users/roxor/rq-rair-pkgI/bt -x --no-header -q", env=ENV)
    return counts(r.stdout + r.stderr), (r.stdout + r.stderr).strip().splitlines()[-1][:160]

def linux():
    cmd = ("docker run --rm --cap-add SYS_ADMIN -v " + str(REPO) + ":/repo:ro -w /repo "
           "-e PYTHONPATH=/repo/src:/repo -e TUSHARE_TOKEN_MAIN=x0000000000000000000000000000000 "
           "-e DATA_DIR=/var/tmp/rq/data -e DUCKDB_PATH=/var/tmp/rq/data/r.duckdb "
           "-e PARQUET_DIR=/var/tmp/rq/data/parquet -e LOG_DIR=/var/tmp/rq/logs rq-rair-cred:1 "
           "bash -c 'mkdir -p /var/tmp/rq/bt && python -m pytest "
           "tests/integration/test_systemd_credential_delivery_linux.py -m linux_exact -q "
           "-p no:cacheprovider --basetemp=/var/tmp/rq/bt --no-header'")
    r = run(cmd, env=None)
    return counts(r.stdout + r.stderr), (r.stdout + r.stderr).strip().splitlines()[-1][:160]

def apply(pairs):
    text = SRC.read_text()
    for old, new in pairs:
        assert old in text, f"anchor missing: {old[:60]}"
        text = text.replace(old, new, 1)
    SRC.write_text(text)

results = {}
only = sys.argv[1:] if len(sys.argv) > 1 else list(MUTATIONS)
for name in only:
    pairs = MUTATIONS[name]
    try:
        apply(pairs)
        t = time.time()
        mf, mline = mac()
        lf, lline = linux()
        results[name] = {"mac_caught": mf, "linux_caught": lf, "mac": mline, "linux": lline,
                         "secs": round(time.time()-t, 1)}
    finally:
        subprocess.run(["git", "checkout", "--", str(SRC)], cwd=str(REPO), check=True)
    print(json.dumps({name: results[name]}), flush=True)
print(json.dumps(results, indent=1))
