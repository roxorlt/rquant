import sys, os
sys.path.insert(0, "/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-i-cc/src")
from pathlib import Path
import rquant.runtime_capabilities as rc
root = Path("/Users/roxor/rq-rair-pkgI/fakeroot"); unit = "rquant-runtime-notifier@svc-" + "a"*64 + ".service"
d = root / unit; d.mkdir(parents=True, exist_ok=True)
(d / "capabilities.json").write_text("{}")
cg = root / "cgroup"; cg.write_text("0::/system.slice/%s\n" % unit)
rc._SYSTEMD_CGROUP_PATH = cg; rc._SYSTEMD_CREDENTIALS_ROOT = root
print("dir readable  ->", rc._undelivered_credential_reason()[:95])
d.chmod(0o000)
try:
    print("dir EACCES    ->", rc._undelivered_credential_reason()[:95])
finally:
    d.chmod(0o700)
