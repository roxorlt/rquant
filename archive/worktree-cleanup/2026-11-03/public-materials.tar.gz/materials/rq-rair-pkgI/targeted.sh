#!/bin/bash
V="$1"; PY="$2"; BT="$3"
cd /Users/roxor/brain/30-projects/rQuant/.worktrees/ra-i-cc
TUSHARE_TOKEN_MAIN=00000000000000000000000000000000placeholder \
DATA_DIR=/Users/roxor/rq-rair-pkgI/data DUCKDB_PATH=/Users/roxor/rq-rair-pkgI/data/rquant.duckdb \
PARQUET_DIR=/Users/roxor/rq-rair-pkgI/data/parquet LOG_DIR=/Users/roxor/rq-rair-pkgI/logs \
"$PY" -m pytest -q -p no:cacheprovider --basetemp="$BT" --no-header \
  tests/unit/test_systemd_credential_delivery_shape.py tests/unit/test_runtime_capabilities.py \
  tests/unit/test_credstore_capability_delivery.py tests/unit/test_credstore_role_child_environment.py \
  tests/unit/test_runtime_credential_keys.py tests/unit/test_runtime_credential_sealer_client.py \
  tests/unit/test_runtime_credential_sealer_helper.py tests/unit/test_provision_runtime_recovery_credentials.py \
  tests/unit/test_runtime_systemd_services.py tests/integration/test_source_broker_peer_credentials.py \
  tests/integration/test_production_artifact_terminal_lifecycle.py \
  tests/integration/test_route_a_credstore_roles_e2e.py 2>&1 | tail -3 > /Users/roxor/rq-rair-pkgI/targeted-$V.txt
echo "done $V"
