#!/bin/bash
mkdir -p /run/credentials && chmod 0755 /run/credentials && chown root:root /run/credentials
groupadd -g 1001 others 2>/dev/null; useradd -u 1000 -g 1001 -M reader 2>/dev/null
n=0
mk() { # $1 label ; env: FILE_OWN FILE_MODE DIR_OWN DIR_MODE RO READER_GROUPS
  n=$((n+1)); U="rquant-runtime-daily-close@svc-$(printf 'd%.0s' $(seq 1 64)).service"
  D="/run/credentials/probe${n}-${U}"
  mkdir -p "$D"; mount -t tmpfs tmpfs "$D" -o nosuid,nodev,noexec,mode=0700
  cp /repo-cred.json "$D/capabilities.json"
  chown $FILE_OWN "$D/capabilities.json"; chmod $FILE_MODE "$D/capabilities.json"
  chown $DIR_OWN "$D"; chmod $DIR_MODE "$D"
  [ "$RO" = 1 ] && mount -o remount,ro,nosuid,nodev,noexec,mode=0700 "$D"
  echo "### $1"
  echo -n "    dir : "; ls -lnd "$D" | awk '{print $1,$3,$4}'
  echo -n "    file: "; ls -ln "$D/capabilities.json" | awk '{print $1,$3,$4}'
  echo -n "    mnt : "; grep -F " $D " /proc/self/mountinfo | awk '{print $6}'
  echo -n "    -> "; setpriv --reuid=1000 --regid=$RGID $RGRP python3 /harness/reader.py "$D/capabilities.json" \
     | python3 -c 'import sys,json;d=json.load(sys.stdin);print(("ACCEPTED" if d["ok"] else "refused: "+d["error"]))'
}
FILE_OWN=root:others FILE_MODE=0440 DIR_OWN=root:root DIR_MODE=0550 RO=1 RGID=1001 RGRP="--groups=0" \
  mk "A. F9 shape: root-owned 0440 but group=others (the shape the brief names)"
FILE_OWN=root:root FILE_MODE=0440 DIR_OWN=root:root DIR_MODE=0500 RO=1 RGID=0 RGRP="--clear-groups" \
  mk "B. directory not searchable by the reader (wrong User=): what does the message say"
FILE_OWN=1000:1001 FILE_MODE=0400 DIR_OWN=1000:1001 DIR_MODE=0500 RO=1 RGID=1001 RGRP="--clear-groups" \
  mk "C. systemd's FULL ownership fallback (ramfs: file AND dir chowned, mount ro)"
FILE_OWN=root:root FILE_MODE=0440 DIR_OWN=root:root DIR_MODE=0550 RO=0 RGID=0 RGRP="--clear-groups" \
  mk "D. ACL-branch shape on a READ-WRITE mount (systemd always remounts ro before MS_MOVE)"
