#!/bin/bash
# Build the exact production delivery shape and read it back as a non-root process.
set -u
UNIT="${UNIT:-rquant-runtime-daily-close@svc-$(printf 'a%.0s' {1..64}).service}"
DIR="/run/credentials/$UNIT"
FS="${FS:-tmpfs}"
MOUNTOPTS="${MOUNTOPTS:-nosuid,nodev,noexec,mode=0700}"
READER_UID="${READER_UID:-1000}"
READER_GID="${READER_GID:-1000}"
FILE_MODE="${FILE_MODE:-0400}"
DIR_MODE="${DIR_MODE:-0500}"
DO_ACL="${DO_ACL:-1}"
DO_RO="${DO_RO:-1}"
CHOWN_FILE="${CHOWN_FILE:-}"
CHOWN_DIR="${CHOWN_DIR:-}"
EXTRA_LINK="${EXTRA_LINK:-}"

mkdir -p /run/credentials && chmod 0755 /run/credentials && chown root:root /run/credentials
mkdir -p "$DIR"
if [ "$FS" != "none" ]; then
  mount -t "$FS" "$FS" "$DIR" -o "$MOUNTOPTS" || { echo "MOUNT-FAILED $FS"; exit 90; }
fi
printf '%s' "$(cat /repo-cred.json)" > "$DIR/capabilities.json"
chown root:root "$DIR/capabilities.json"
chmod "$FILE_MODE" "$DIR/capabilities.json"
if [ -n "$EXTRA_LINK" ]; then ln "$DIR/capabilities.json" "$DIR/extra.link"; fi
ACLSTATUS=skipped
if [ "$DO_ACL" = "1" ]; then
  if setfacl -m "u:${READER_UID}:r" "$DIR/capabilities.json" 2>/tmp/aclerr; then ACLSTATUS=file-ok; else ACLSTATUS="file-FAILED: $(cat /tmp/aclerr)"; fi
fi
chown root:root "$DIR"
chmod "$DIR_MODE" "$DIR"
if [ "$DO_ACL" = "1" ]; then
  if setfacl -m "u:${READER_UID}:rx" "$DIR" 2>/tmp/aclerr2; then ACLSTATUS="$ACLSTATUS dir-ok"; else ACLSTATUS="$ACLSTATUS dir-FAILED: $(cat /tmp/aclerr2)"; fi
fi
[ -n "$CHOWN_FILE" ] && chown "$CHOWN_FILE" "$DIR/capabilities.json"
[ -n "$CHOWN_DIR" ] && chown "$CHOWN_DIR" "$DIR"
if [ "$DO_RO" = "1" ] && [ "$FS" != "none" ]; then
  mount -o remount,ro,"$MOUNTOPTS" "$DIR" || echo "REMOUNT-RO-FAILED"
fi
echo "=== acl: $ACLSTATUS"
echo "=== ls -ln dir:"; ls -lnd "$DIR"
echo "=== ls -ln file:"; ls -ln "$DIR/capabilities.json"
echo "=== getfacl:"; getfacl -p "$DIR/capabilities.json" 2>&1 | sed 's/^/    /'
echo "=== mountinfo:"; grep -F "$DIR" /proc/self/mountinfo || echo "    (no per-unit mount line)"
echo "=== stat dev:"; python3 -c "import os,sys; s=os.stat(sys.argv[1]); print('%d:%d'%(os.major(s.st_dev),os.minor(s.st_dev)))" "$DIR"
echo "=== READBACK as uid ${READER_UID}:"
setpriv --reuid="$READER_UID" --regid="$READER_GID" --clear-groups python3 /harness/reader.py "$DIR/capabilities.json"
