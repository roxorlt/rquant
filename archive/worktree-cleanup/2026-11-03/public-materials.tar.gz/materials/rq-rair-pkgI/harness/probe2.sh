#!/bin/bash
mkdir -p /run/credentials && chmod 0755 /run/credentials && chown root:root /run/credentials
groupadd -g 1001 others 2>/dev/null; useradd -u 1000 -g 1001 -M reader 2>/dev/null
n=0
mk() {
  n=$((n+1)); U="rquant-runtime-daily-close@svc-$(printf 'e%.0s' $(seq 1 64)).service"
  D="/run/credentials/p${n}-${U}"
  mkdir -p "$D"; mount -t "$FS" "$FS" "$D" -o nosuid,nodev,noexec,mode=0700 || { echo "MOUNT FAILED $FS"; return; }
  cp /repo-cred.json "$D/capabilities.json"
  chown $FILE_OWN "$D/capabilities.json"; chmod $FILE_MODE "$D/capabilities.json"
  chown $DIR_OWN "$D"; chmod $DIR_MODE "$D"
  [ "$RO" = 1 ] && mount -o remount,ro,nosuid,nodev,noexec,mode=0700 "$D"
  echo "### $1"
  printf "    fs=%-6s mnt=%s\n" "$FS" "$(grep -F " $D " /proc/self/mountinfo | awk '{print $6}')"
  printf "    dir=%s %s   file=%s %s\n" "$(ls -lnd "$D"|awk '{print $1}')" "$(ls -lnd "$D"|awk '{print $3":"$4}')" \
         "$(ls -ln "$D/capabilities.json"|awk '{print $1}')" "$(ls -ln "$D/capabilities.json"|awk '{print $3":"$4}')"
  printf "    -> "; setpriv --reuid=1000 --regid=$RGID $RGRP python3 /harness/reader.py "$D/capabilities.json" \
     | python3 -c 'import sys,json;d=json.load(sys.stdin);print("ACCEPTED" if d["ok"] else "refused: "+d["error"][:210])'
}
FS=tmpfs FILE_OWN=root:root FILE_MODE=0440 DIR_OWN=root:root DIR_MODE=0550 RO=1 RGID=0 RGRP="--clear-groups" \
  mk "P1 生产 ACL 形状（ro tmpfs）"
FS=tmpfs FILE_OWN=root:root FILE_MODE=0440 DIR_OWN=root:root DIR_MODE=0550 RO=0 RGID=0 RGRP="--clear-groups" \
  mk "P2 同上但挂载 rw（SF-2：ACL 支也必须 ro）"
FS=ramfs FILE_OWN=1000:1001 FILE_MODE=0400 DIR_OWN=1000:1001 DIR_MODE=0500 RO=1 RGID=1001 RGRP="--clear-groups" \
  mk "P3 完整属主 fallback，真 ramfs + ro（SF-1）"
FS=ramfs FILE_OWN=1000:1001 FILE_MODE=0400 DIR_OWN=1000:1001 DIR_MODE=0500 RO=0 RGID=1001 RGRP="--clear-groups" \
  mk "P4 同上但 rw"
FS=tmpfs FILE_OWN=root:root FILE_MODE=0440 DIR_OWN=root:root DIR_MODE=0500 RO=1 RGID=0 RGRP="--clear-groups" \
  mk "P5 目录进不去（User= 配错的真实症状）（MF-2）"
FS=tmpfs FILE_OWN=root:root FILE_MODE=0440 DIR_OWN=65534:65534 DIR_MODE=0550 RO=1 RGID=0 RGRP="--clear-groups" \
  mk "P6 目录属第三方（D4 放宽后仍须拒）"
FS=tmpfs FILE_OWN=root:others FILE_MODE=0440 DIR_OWN=root:root DIR_MODE=0550 RO=1 RGID=1001 RGRP="--groups=0" \
  mk "P7 root:others 0440（MF-1 形状）"
FS=tmpfs FILE_OWN=1000:1001 FILE_MODE=0400 DIR_OWN=root:root DIR_MODE=0550 RO=1 RGID=1001 RGRP="--groups=0" \
  mk "P8 只有文件走 fallback、目录仍 root（ro）"
