import json, os, sys
sys.path.insert(0, "/repo/src")
from pathlib import Path
from rquant import runtime_capabilities as rc
if len(sys.argv) > 2:
    rc._SYSTEMD_MOUNT_TABLE = Path(sys.argv[2])
if len(sys.argv) > 3:
    rc._SYSTEMD_CREDENTIALS_ROOT = Path(sys.argv[3])
path = Path(sys.argv[1])
out = {"uid": os.geteuid(), "gid": os.getegid(), "groups": sorted(os.getgroups()),
       "table": str(rc._SYSTEMD_MOUNT_TABLE), "root": str(rc._SYSTEMD_CREDENTIALS_ROOT)}
try:
    out["plaintext"] = rc._read_private_credential(path).decode(); out["ok"] = True
except Exception as exc:
    out["ok"] = False; out["error"] = str(exc)
print(json.dumps(out))
