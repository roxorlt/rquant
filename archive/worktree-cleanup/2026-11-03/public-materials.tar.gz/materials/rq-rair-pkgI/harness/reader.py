import json, os, sys
sys.path.insert(0, "/repo/src")
from pathlib import Path
from rquant import runtime_capabilities as rc

path = Path(sys.argv[1])
out = {
    "uid": os.geteuid(), "gid": os.getegid(), "groups": sorted(os.getgroups()),
}
try:
    payload = rc._read_private_credential(path)
    out["ok"] = True
    out["bytes"] = len(payload)
    out["plaintext"] = payload.decode()
except Exception as exc:
    out["ok"] = False
    out["error_type"] = type(exc).__name__
    out["error"] = str(exc)
print(json.dumps(out))
