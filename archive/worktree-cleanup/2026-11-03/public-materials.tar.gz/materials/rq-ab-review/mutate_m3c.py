import pathlib
ROOT = pathlib.Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-ab-cc")
SNAP = ROOT / "src/rquant/runtime_serving_snapshot.py"
BLD = ROOT / "src/rquant/runtime_builder_serving.py"
PROF = ROOT / "src/rquant/runtime_production_profile.py"

s = SNAP.read_text()
# guard 1: assembler constructor
g1_start = s.index("        if REFERENCE_SLOW_AUTHORITY_DATASET_ID in optional_datasets:")
g1_end = s.index('raise ValueError("reference_slow_authority can never be an optional serving source")', g1_start)
g1_end = s.index("\n", g1_end) + 1
s = s[:g1_start] + s[g1_end:]
# guard 3: read-side carve-out
g3 = "            if payload_type is ReferenceSlowPayload:\n                raise RuntimeError(f\"{dataset_id} reader failed: {_error_text(error)}\") from error\n"
assert s.count(g3) == 1
s = s.replace(g3, "")
SNAP.write_text(s)

b = BLD.read_text()
g2 = '        if _REFERENCE_SLOW_AUTHORITY_DATASET_ID in value:\n            raise ValueError("reference_slow_authority can never be an optional serving source")\n'
assert b.count(g2) == 1
BLD.write_text(b.replace(g2, ""))

p = PROF.read_text()
old = '"optional_source_datasets": ["lab_jobs", "promotions"],'
assert p.count(old) == 1
PROF.write_text(p.replace(old, '"optional_source_datasets": ["lab_jobs", "promotions", "reference_slow_authority"],'))
print("M3c applied: 3 guards removed + profile widened")
