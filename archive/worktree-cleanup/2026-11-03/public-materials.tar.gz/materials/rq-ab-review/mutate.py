import sys, pathlib
ROOT = pathlib.Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-ab-cc")
SNAP = ROOT / "src/rquant/runtime_serving_snapshot.py"
BLD = ROOT / "src/rquant/runtime_builder_serving.py"

MUT = {
 "M1": (SNAP,
   "            if dataset_id not in self.optional_datasets:",
   "            if False:  # MUTANT M1: bare fail_closed=False, every source degrades"),
 "M2": (BLD,
   'DEFAULT_OPTIONAL_SOURCE_DATASETS: frozenset[str] = frozenset({"lab_jobs", "promotions"})',
   'DEFAULT_OPTIONAL_SOURCE_DATASETS: frozenset[str] = frozenset({"lab_jobs", "promotions", "reference_slow_authority"})  # MUTANT M2'),
 "M4": (SNAP,
   '                        "dataset_id": dataset_id,\n                        "reason": reason,',
   '                        "dataset_id": dataset_id,\n                        "as_of": as_of,  # MUTANT M4\n                        "reason": reason,'),
 "M4b": (SNAP,
   "                event_time=UNAVAILABLE_EVIDENCE_INSTANT,\n                published_at=UNAVAILABLE_EVIDENCE_INSTANT,",
   "                event_time=as_of,  # MUTANT M4b\n                published_at=as_of,"),
 "M5": (BLD,
   "        if watermark.status is not FreshnessStatus.FRESH",
   "        if watermark.status not in (FreshnessStatus.FRESH, FreshnessStatus.UNAVAILABLE)  # MUTANT M5"),
 "M6": (BLD,
   "                optional_datasets=frozenset(settings.optional_source_datasets),",
   "                optional_datasets=DEFAULT_OPTIONAL_SOURCE_DATASETS,  # MUTANT M6: manifest list ignored"),
}
name = sys.argv[1]
path, old, new = MUT[name]
text = path.read_text()
assert text.count(old) == 1, f"{name}: anchor found {text.count(old)} times"
path.write_text(text.replace(old, new))
print(f"applied {name} to {path.name}")
