"""My own io probe: does serving rewrite itself while the research plane is absent?

Counts, over N steps: how many steps reported generation_published, how many steps
changed the serving tree at all (mode/size/mtime of every entry), and how many
generation directories exist at the end.
"""
import sys, tempfile, shutil
from datetime import timedelta
from pathlib import Path

ROOT = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-ab-cc")
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))

from tests.unit.test_runtime_builder_serving import (  # noqa: E402
    NOW, LAB_JOBS_DATASET_ID, PROMOTIONS_DATASET_ID, _authority_settings, _manifest,
)
from tests.runtime_readonly_sandbox import tree_state  # noqa: E402
from rquant.runtime_builder_serving import serving_publisher_builder  # noqa: E402

STEPS = int(sys.argv[1]) if len(sys.argv) > 1 else 25
tmp = Path(tempfile.mkdtemp(prefix="probe-", dir="/Users/roxor/rq-ab-review/scratch"))
try:
    absent = frozenset({LAB_JOBS_DATASET_ID, PROMOTIONS_DATASET_ID})
    settings, _roots = _authority_settings(tmp, unpublished=absent)
    clock = [NOW]
    step = serving_publisher_builder(snapshot_loader=None, clock=lambda: clock[0])(
        _manifest(tmp, settings=settings)
    )
    serving_root = tmp / "serving"

    first = step()
    print(f"step 0 (bootstrap): generation_published={first.generation_published}")
    settled = tree_state(serving_root)

    rebuilt = 0
    tree_moved = 0
    for i in range(1, STEPS + 1):
        clock[0] = NOW + timedelta(seconds=30 * i)
        result = step()
        if result.generation_published:
            rebuilt += 1
        now_state = tree_state(serving_root)
        if now_state != settled:
            tree_moved += 1
            settled = now_state
    gens = sorted(p.name for p in (serving_root / "generations").iterdir() if p.is_dir())
    print(f"steps={STEPS}  generation_published=True on {rebuilt}/{STEPS}")
    print(f"steps that moved the serving tree (byte-level stat): {tree_moved}/{STEPS}")
    print(f"generation directories at the end: {len(gens)}")
    print(f"current.json present: {(serving_root / 'current.json').is_file()}")
finally:
    shutil.rmtree(tmp, ignore_errors=True)
