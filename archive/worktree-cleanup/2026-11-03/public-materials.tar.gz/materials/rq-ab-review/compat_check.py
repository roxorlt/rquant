import importlib.util, sys, json
from pathlib import Path

root = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-ab-cc")
sys.path.insert(0, str(root / "src"))

from rquant.runtime_builder_serving import ServingRuntimeSettings as NewSettings

AUTHS = [
    {"dataset_id": d, "root": f"/srv/runtime/auth/{d}"}
    for d in ("signals", "paper_accounts", "runtime_health", "lab_jobs", "promotions", "reference_slow_authority")
]
OLD_MANIFEST = {"serving_root": "/srv/serving", "schema_version": 3, "source_authorities": AUTHS}
NEW_MANIFEST = dict(OLD_MANIFEST, optional_source_datasets=["lab_jobs", "promotions"])

print("== 1. OLD manifest (no key) + NEW code ==")
s = NewSettings.model_validate(OLD_MANIFEST)
print("   OK ->", s.optional_source_datasets)

print("== 2. NEW manifest (with key) + NEW code ==")
s2 = NewSettings.model_validate(NEW_MANIFEST)
print("   OK ->", s2.optional_source_datasets)

spec = importlib.util.spec_from_file_location("v3315_builder_serving", "/Users/roxor/rq-ab-review/v3315/old_builder_serving.py")
mod = importlib.util.module_from_spec(spec)
sys.modules["v3315_builder_serving"] = mod
spec.loader.exec_module(mod)
OldSettings = mod.ServingRuntimeSettings
print("== v0.33.15 field set ==", sorted(OldSettings.model_fields))

print("== 3. OLD manifest + v0.33.15 code ==")
print("   OK ->", OldSettings.model_validate(OLD_MANIFEST).serving_root)

print("== 4. NEW manifest + v0.33.15 code ==")
try:
    OldSettings.model_validate(NEW_MANIFEST)
    print("   !!! ACCEPTED (unexpected)")
except Exception as e:
    errs = getattr(e, "errors", lambda: [])()
    print("   REJECTED ->", [(x["type"], x["loc"]) for x in errs])
