import sys, pathlib
ROOT = pathlib.Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-ab-cc")
BLD = ROOT / "src/rquant/runtime_builder_serving.py"
MUT = {
 "M6": (BLD,
   "                optional_datasets=frozenset(settings.optional_source_datasets),",
   "                optional_datasets=DEFAULT_OPTIONAL_SOURCE_DATASETS,  # MUTANT M6"),
 "M7": (BLD,
   '    _REFERENCE_SLOW_AUTHORITY_DATASET_ID: "reference_slow",\n}',
   '    _REFERENCE_SLOW_AUTHORITY_DATASET_ID: "reference_slow",\n    "seventh_source": "seventh",  # MUTANT M7: added in one place only\n}'),
}
name = sys.argv[1]
path, old, new = MUT[name]
t = path.read_text()
assert t.count(old) == 1, f"{name}: anchor {t.count(old)}x"
path.write_text(t.replace(old, new))
print(f"applied {name}")
