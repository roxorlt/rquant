from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-ab-cc/.superpowers/sdd/2026-09-21-serving-optional-research-sources/pkgAB-review.md")
t = p.read_text()

reps = [
# io probe: add mutation numbers
("""**25 次迭代（12.5 分钟模拟时间）里 0 次重建、serving 目录一个 stat 字段都没动、
最终只有 1 个 generation 目录。** 变异 M4 / M4b 之下，实现者那条 60 步用例
（`test_sixty_idle_steps_with_the_research_plane_absent_leave_one_generation`）
在我这里两次都红（`[True]*60 != [False]*60`），即 60/60 全重建。与报告的口径一致。""",
"""**同一支探针在两条变异下再跑一遍**（这是本条的关键对照）：

| 代码 | 25 步里重建了几次 | 有几步动了 serving 目录 | 最终 generation 目录数 |
|---|---|---|---|
| **本包 HEAD** | **0 / 25** | **0 / 25** | **1** |
| 变异 **M4**（generation_id 含 `as_of`） | **25 / 25** | **25 / 25** | **26** |
| 变异 **M4b**（只有水位含 `as_of`，generation_id 已干净） | **25 / 25** | **25 / 25** | **26** |

**M4b 这一行是整包最值得记下来的一个数**：generation_id 里的时钟已经去掉了，
只剩水位那两个时刻带时钟，serving 就**照样每三十秒重建一次完整的 `serving.duckdb`**
（建库 → 校验 → 取哈希 → fsync → 换 `current.json`），一次都没省下。
简报给的「二选一」如果只做一半，#271 就白修了。实现者发现并补上了这半步。

实现者那条 60 步用例（`test_sixty_idle_steps_with_the_research_plane_absent_leave_one_generation`）
在我这里 M4 / M4b 之下两次都红（`[True]*60 != [False]*60`），与我的探针同向。"""),

# M6 broad evidence
("""我把方向反过来做一次（让运行期忽略 manifest、退回常量），
33 条 unit 一条都没红。""",
"""我把方向反过来做一次（让运行期忽略 manifest、退回常量），
**33 条 unit 一条都没红；再把范围扩到 serving 相关的六个文件（加上
`test_runtime_production_profile` / `test_runtime_service_builtin` /
`test_default_serving_runtime` / `test_serving_page_projection_e2e`），
193 条也全绿（409.67s）。**"""),

("| **M6（我自己加的）** | `runtime_builder_serving.py:313` 的 `optional_datasets=frozenset(settings.optional_source_datasets)` → `optional_datasets=DEFAULT_OPTIONAL_SOURCE_DATASETS`（**manifest 那份被忽略，退回常量**） | **33 passed，4.39s — SURVIVED** | ❌ 报告没做这一条 |",
 "| **M6（我自己加的）** | `runtime_builder_serving.py:313` 的 `optional_datasets=frozenset(settings.optional_source_datasets)` → `optional_datasets=DEFAULT_OPTIONAL_SOURCE_DATASETS`（**manifest 那份被忽略，退回常量**） | **33 passed，4.39s — SURVIVED**；扩到 serving 相关六个文件 **193 passed，409.67s — 仍然 SURVIVED** | ❌ 报告没做这一条 |"),

# numbers table
("""| `tests/integration/test_route_a_idle_writers_e2e.py`（包 W） | 2 passed / 134.76s | 见下 |
| 抽查一组（serving 相关五个 unit 文件） | —— | 见下 |""",
"""| `tests/integration/test_route_a_idle_writers_e2e.py`（包 W） | 2 passed / 134.76s | **2 passed / 133.16s** ✅ |
| 抽查一组：`test_serving_publisher` + `test_serving_contracts` + `test_lab_jobs_serving_authority` + `test_promotions_serving_authority` + `test_runtime_serving_authority` | 报告未单列 | **111 passed / 16.64s** ✅ |
| M6 变异用的扩展组（上面两个 unit + `test_runtime_production_profile` + `test_runtime_service_builtin` + `test_default_serving_runtime` + `test_serving_page_projection_e2e`） | —— | **193 passed / 409.67s**（干净树下同样全绿） |"""),

("""- **复现**：把 `:313` 改成 `optional_datasets=DEFAULT_OPTIONAL_SOURCE_DATASETS,`
  → `pytest tests/unit/test_runtime_serving_snapshot.py tests/unit/test_runtime_builder_serving.py -q`
  → **33 passed**""",
"""- **复现**：把 `:313` 改成 `optional_datasets=DEFAULT_OPTIONAL_SOURCE_DATASETS,`
  → `pytest tests/unit/test_runtime_serving_snapshot.py tests/unit/test_runtime_builder_serving.py -q`
  → **33 passed**；扩到 serving 相关六个文件 → **193 passed**"""),
]
for old, new in reps:
    assert t.count(old) == 1, f"anchor miss ({t.count(old)}): {old[:60]}"
    t = t.replace(old, new)
p.write_text(t)
print("patched")
