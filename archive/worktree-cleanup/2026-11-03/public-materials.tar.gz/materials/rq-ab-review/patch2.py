from pathlib import Path
p = Path("/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-ab-cc/.superpowers/sdd/2026-09-21-serving-optional-research-sources/pkgAB-review.md")
t = p.read_text()
reps = [
("""三道全拆掉（实现者的 M3c）会被 e2e 反向用例接住，**我复跑确认**（见第四节 M3c 行）。
机制我也独立核过：carve-out 按 `payload_type is ReferenceSlowPayload` 判，
而 `ReferenceSlowPayload`（`:217-219`）五个字段全必填，所以拆掉 carve-out 之后
`payload_type()` 根本构造不出来——降级只会把一条具名拒绝换成一次无名 `ValidationError`。
这正是「它没有合法空值」这句话的可执行形式。""",
"""**三道全拆掉（实现者的 M3c）确实被 e2e 反向用例接住 —— 我自己跑了一遍。**
把上面三处全删掉，再把画像的列表改成
`["lab_jobs", "promotions", "reference_slow_authority"]`（也就是主机真会走到的那条完整路径），
跑 `pytest …full_chain_e2e.py -k without_the_reference_authority`：

```
1 failed, 11 deselected in 39.25s
…full_chain_e2e.py:1728: AssertionError: ValidationError: 5 validation errors for ReferenceSlowPayload
```

与报告逐字一致。报错本身就是机制的说明：carve-out 按 `payload_type is ReferenceSlowPayload` 判，
而 `ReferenceSlowPayload`（`:217-219`）五个字段全必填，所以拆掉之后 `payload_type()`
**根本构造不出来**——所谓「降级」只会把一条具名拒绝（`reference_slow_authority reader failed`）
换成一次无名崩溃。这正是「它没有合法空值」这句话的可执行形式。"""),

("| **M3c** | 三道闸全开（两处校验删掉 + 画像列表加 `reference_slow_authority`），走 e2e 反向用例 | 见下 | 见下 |",
 "| **M3c** | 三道闸全开：两处校验 + 读侧 carve-out 三处全删，再把画像列表改成 `[\"lab_jobs\", \"promotions\", \"reference_slow_authority\"]`；范围 e2e `-k without_the_reference_authority` | **1 failed / 11 deselected，39.25s — KILLED**，报 `ValidationError: 5 validation errors for ReferenceSlowPayload` | ✅ 逐字一致 |"),
]
for old, new in reps:
    assert t.count(old) == 1, f"miss: {old[:50]}"
    t = t.replace(old, new)
p.write_text(t)
print("patched")
