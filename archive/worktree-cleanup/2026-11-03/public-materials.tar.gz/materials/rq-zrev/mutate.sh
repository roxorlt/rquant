#!/bin/zsh
set -u
W=/Users/roxor/brain/30-projects/rQuant/.worktrees/ra-z-cc
cd $W
source /Users/roxor/rq-zrev/root/env.sh
export PYTHONDONTWRITEBYTECODE=1
PY=$W/.venv/bin/python
LOGS=/Users/roxor/rq-zrev/logs
FILE=tests/integration/test_route_a_trading_day_full_chain_e2e.py

apply () {  # apply <file> <python-repl-script>
  $PY - "$1" <<PYEOF
import sys, pathlib
p = pathlib.Path(sys.argv[1]); t = p.read_text()
old, new = ${2}
assert t.count(old) == 1, (p, t.count(old))
p.write_text(t.replace(old, new))
print("mutated", p)
PYEOF
}

run () {  # run <tag> <extra pytest args...>
  tag=$1; shift
  echo "=== $tag ===" 
  $PY -m pytest "$@" -q -p no:randomly > $LOGS/$tag.log 2>&1
  echo "EXIT=$?"
  grep -E "^(FAILED|ERROR)" $LOGS/$tag.log | sed 's/ - .*//' | sort -u
  tail -3 $LOGS/$tag.log | grep -E "passed|failed|error"
}

clean () { git checkout -- src tests 2>/dev/null; git status --porcelain | grep -v '^?? ' && echo "DIRTY!" || echo "clean"; }

clean

# ---- MR: revert the defect-A fix (shared lock back to O_RDWR|O_CREAT) ----
apply src/rquant/reference_data_registry.py '("        if not exclusive:\n            try:", "        if False:  # MUTATION\n            try:")'
run MR-reference-fix-reverted $FILE tests/unit/test_reference_data_registry.py
clean

# ---- M1: feature writes no spool batch ----
apply src/rquant/feature_live_service.py '("        feature_spool.publish(result.envelope, result.payload_bytes)", "        pass  # MUTATION")'
run M1-feature-no-spool $FILE
clean

# ---- M2: n_shape never emits ----
apply src/rquant/strategy_evaluators.py '("    if carrying and breakout and vwap_strong and below_limit:", "    if False and carrying and breakout and vwap_strong and below_limit:  # MUTATION")'
run M2-strategy-no-signal $FILE
clean

# ---- M3: router enumerates no source ----
apply src/rquant/runtime_builder_signal.py '("            for index, source_settings in enumerate(settings.source_settings):", "            for index, source_settings in enumerate(()):  # MUTATION")'
run M3-router-no-route $FILE
clean

# ---- M4: serving never switches the current pointer ----
apply src/rquant/serving_publisher.py '("            os.replace(temporary, self.current_path)", "            pass  # MUTATION")'
run M4-serving-no-publish $FILE
clean

echo "=== FINAL STATUS ==="
git status --porcelain
