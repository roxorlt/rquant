"""Does flock(LOCK_SH) on an O_RDONLY descriptor still serialize against LOCK_EX?"""
import fcntl, os, tempfile, time, multiprocessing as mp

def writer(path, started, release):
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o600)
    fcntl.flock(fd, fcntl.LOCK_EX)
    started.set()
    release.wait(5)
    fcntl.flock(fd, fcntl.LOCK_UN); os.close(fd)

if __name__ == "__main__":
    d = tempfile.mkdtemp(dir="/Users/roxor/rq-zrev")
    p = os.path.join(d, ".reference.sqlite3.publication.lock")
    os.close(os.open(p, os.O_RDWR | os.O_CREAT, 0o600))
    started, release = mp.Event(), mp.Event()
    w = mp.Process(target=writer, args=(p, started, release)); w.start(); started.wait(5)

    fd = os.open(p, os.O_RDONLY)                       # the reader, as the fix opens it
    try:
        fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB) # must block -> EWOULDBLOCK
        print("BAD: shared lock granted while an exclusive lock is held")
    except OSError as exc:
        print(f"blocking confirmed while writer holds LOCK_EX: errno {exc.errno} ({exc.strerror})")
    t0 = time.perf_counter(); release.set(); w.join()
    fcntl.flock(fd, fcntl.LOCK_SH)                     # blocking form succeeds after release
    print(f"shared lock on an O_RDONLY fd acquired after the writer released, {time.perf_counter()-t0:.3f}s")
    # and a second reader may share it
    fd2 = os.open(p, os.O_RDONLY); fcntl.flock(fd2, fcntl.LOCK_SH | fcntl.LOCK_NB)
    print("two O_RDONLY readers hold LOCK_SH at once: yes")
    # while a writer may not
    w2 = os.open(p, os.O_RDWR)
    try:
        fcntl.flock(w2, fcntl.LOCK_EX | fcntl.LOCK_NB); print("BAD: exclusive granted over readers")
    except OSError as exc:
        print(f"exclusive refused while readers hold LOCK_SH: errno {exc.errno} ({exc.strerror})")
    # and the read-only descriptor really is read-only
    try:
        os.write(fd, b"x"); print("BAD: wrote through the O_RDONLY descriptor")
    except OSError as exc:
        print(f"O_RDONLY descriptor cannot write: errno {exc.errno} ({exc.strerror})")
