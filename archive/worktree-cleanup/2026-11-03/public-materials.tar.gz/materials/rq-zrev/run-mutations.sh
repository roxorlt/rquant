#!/bin/zsh
# wait for the regression run to finish before touching src
until ! pgrep -f "test_route_a_idle_writers_e2e.py" > /dev/null 2>&1; do sleep 15; done
sleep 5
exec /Users/roxor/rq-zrev/mutate.sh
